#Observed Agreement

#Data Loading
library(readxl)
Dat1 <- as.data.frame(read_xlsx("All_run_GH.xlsx", sheet = 1))
Dat1 <- Dat1[1:116,]
rownames(Dat1) <- Dat1$File_name
Dat1 <- Dat1[,-c(1:2)]

Dat2 <- read.csv("Raw_info20240821_done_WW.csv")
rownames(Dat2) <- Dat2$File_name
Dat2 <- Dat2[,-c(1:2)]
Dat2 <- Dat2[rownames(Dat1),]

Dat3 <- read.csv("Raw_ZY_info20240821.csv")
rownames(Dat3) <- Dat3$File_name
Dat3 <- Dat3[,-c(1:2)]
Dat3 <- Dat3[rownames(Dat1),]

#Corrplot
R01 <- data.frame(A = unlist(as.vector(Dat1)), B = unlist(as.vector(Dat2)), C = unlist(as.vector(Dat3)))

R01_Agreement <- matrix(0, ncol(R01), ncol(R01))
library(irr)
for (i in 1:ncol(R01)) {
  for (j in 1:ncol(R01)) {
    R01_Agreement[i,j] <- agree(R01[,c(i,j)])$value / 100
  }
}
rm(i,j)
rownames(R01_Agreement) <- colnames(R01)
colnames(R01_Agreement) <- colnames(R01)

library(corrplot)
corrplot.mixed(R01_Agreement, upper = "color", col.lim = c(0,1), tl.cex = 1.5, number.cex = 1.5)
rm(R01, R01_Agreement)

#Observed Agreement among 3 raters
Dat <- cbind(Dat1, Dat2, Dat3)
D <- matrix(0, 116, 16)
for (i in 1:16) {
  for (j in 1:116) {
    D[j,i] <- max(as.data.frame(table(t(Dat[j, c(i, i + 16, i + 32)])))$Freq)
  }
}
rm(i,j)
rm(Dat)

Result <- vector()
for (i in 1:16) {
  print(table(D[,i]))
  print(as.data.frame(table(D[,i]))$Freq / 116)
  Result <- c(Result, as.data.frame(table(D[,i]))$Freq / 116)  
}
rm(i)
rm(D)

Result <- data.frame(Agreement = rep(c("2","3"), 16), Freq = Result)
Result$Feature <- c(rep("F1",2), rep("F2",2), rep("F3",2), rep("F4",2), rep("F5",2), rep("F6",2), rep("F7",2), rep("F8",2), rep("F9",2), rep("F10",2), rep("F11",2), rep("F12",2), rep("F13",2), rep("F14",2), rep("LC",2), rep("MS",2))
Result$Freq <- 100 * Result$Freq

library(ggplot2)
ggplot(Result, aes(x = Feature, weight = Freq, fill = Agreement)) +
  geom_bar(position = "stack") +
  theme_bw() +
  theme(panel.grid = element_blank()) +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 14, color = "black"), axis.text.y = element_text(size = 14, color = "black")) +
  labs(x = "Feature ID", y = "Percentage (%)") +
  scale_x_discrete(limits = c("F1","F2","F3","F4","F5","F6","F7","F8","F9","F10","F11","F12","F13","F14","LC","MS")) +
  geom_text(aes(label = round(Freq, 0), y = Freq), position = position_stack(vjust = 0.5), size = 2.5) +
  scale_y_continuous(expand = c(0, 0), limits = c(-1, 101)) +
  ggtitle("3 Raters")
rm(Result)

#Observed Agreement Qualified or Not
Dat <- matrix("", 116, 16)
Data <- cbind(Dat1, Dat2, Dat3)
for (i in 1:16) {
  for (j in 1:116) {
    if (sum(t(Data[j, c(i, i + 16, i + 32)]) == "Qualified") > 1) {
      Dat[j,i] <- "Qualified"
    } else {
      Dat[j,i] <- "Unqualified"
    }
  }
}
rm(i,j)

colnames(Dat) <- colnames(Dat1)
Dat <- as.data.frame(Dat)
A <- as.data.frame(rbind(
  as.data.frame(table(Dat$F1)/length(Dat$F1)),
  as.data.frame(table(Dat$F2)/length(Dat$F2)),
  as.data.frame(table(Dat$F3)/length(Dat$F3)),
  as.data.frame(table(Dat$F4)/length(Dat$F4)),
  as.data.frame(table(Dat$F5)/length(Dat$F5)),
  as.data.frame(table(Dat$F6)/length(Dat$F6)),
  as.data.frame(table(Dat$F7)/length(Dat$F7)),
  as.data.frame(table(Dat$F8)/length(Dat$F8)),
  as.data.frame(table(Dat$F9)/length(Dat$F9)),
  as.data.frame(table(Dat$F10)/length(Dat$F10)),
  as.data.frame(table(Dat$F11)/length(Dat$F11)),
  as.data.frame(table(Dat$F12)/length(Dat$F12)),
  as.data.frame(table(Dat$F13)/length(Dat$F13)),
  as.data.frame(table(Dat$F14)/length(Dat$F14)),
  as.data.frame(table(Dat$LC)/length(Dat$LC)),
  as.data.frame(table(Dat$MS)/length(Dat$MS))
))
A$Feature_ID <- rep(c("F1","F2","F3","F4","F5","F6","F7","F8","F9","F10","F11","F12","F13","F14","LC","MS"), each = 2)
colnames(A) <- c("Label","Freq","Feature_ID")
A$Freq <- 100 * A$Freq

library(ggplot2)
ggplot(A, aes(x = Feature_ID, weight = Freq, fill = Label)) +
  geom_bar(position = "stack") +
  theme_bw() +
  theme(panel.grid = element_blank()) +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 14, color = "black"), axis.text.y = element_text(size = 14, color = "black")) +
  labs(x = "Feature ID", y = "Percentage (%)") +
  scale_x_discrete(limits = c("F1","F2","F3","F4","F5","F6","F7","F8","F9","F10","F11","F12","F13","F14","LC","MS")) +
  geom_text(aes(label = round(Freq, 0), y = Freq), position = position_stack(vjust = 0.5), size = 3.5) +
  scale_y_continuous(expand = c(0, 0), limits = c(0, 101))

rm(A, Dat, Data)

rm(Dat1, Dat2, Dat3)
gc()
