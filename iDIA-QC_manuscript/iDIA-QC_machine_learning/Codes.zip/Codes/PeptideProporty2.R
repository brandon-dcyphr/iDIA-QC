#Datasets Analysis 2

library(tidyverse)
Dat <- read_csv("GRAVY.csv")
Dat$length <- nchar(Dat$sequence)

#Length Distribution
ggplot(Dat, aes(x = length)) +
  geom_histogram(bins = 10, alpha = 0.7, position = "identity", size = 1.5, color = "#0072B5FF", fill = "#0072B5FF") +
  theme_classic() +
  theme(axis.title.x = element_text(size = 17), axis.title.y = element_text(size = 17)) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14), legend.position = "none") +
  theme(axis.text.x = element_text(size = 14, color = "black"), axis.text.y = element_text(size = 14, color = "black")) +
  labs(x = "Peptide length", y = "Number of peptides") +
  theme(plot.title = element_text(size = 25, face = "bold"))

#GRAVY Distribution
ggplot(Dat, aes(x = GRAVY)) +
  geom_histogram(bins = 10, alpha = 0.7, position = "identity", size = 1.5, color = "#0072B5FF", fill = "#0072B5FF") +
  theme_classic() +
  theme(axis.title.x = element_text(size = 17), axis.title.y = element_text(size = 17)) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14), legend.position = "none") +
  theme(axis.text.x = element_text(size = 14, color = "black"), axis.text.y = element_text(size = 14, color = "black")) +
  labs(x = "GRAVY value", y = "Number of peptides") +
  theme(plot.title = element_text(size = 25, face = "bold"))

#Dynamic Range

#1
D1 <- read_tsv("1_QEHF1_TPD_A_output.tsv")
D1 <- D1[,c("Stripped.Sequence","Precursor.Quantity")]
Median1 <- vector()
for (i in 1:934) {
  Median1[i] <- median(D1$Precursor.Quantity[which(D1$Stripped.Sequence == Dat$sequence[i])])
}
rm(i)
rm(D1)
gc()

#2
D2 <- read_tsv("2_QEHF1_TPD_B_output.tsv")
D2 <- D2[,c("Stripped.Sequence","Precursor.Quantity")]
Median2 <- vector()
for (i in 1:934) {
  Median2[i] <- median(D2$Precursor.Quantity[which(D2$Stripped.Sequence == Dat$sequence[i])])
}
rm(i)
rm(D2)
gc()

#3
D3 <- read_tsv("3_TPD_C_output.tsv")
D3 <- D3[,c("Stripped.Sequence","Precursor.Quantity")]
Median3 <- vector()
for (i in 1:934) {
  Median3[i] <- median(D3$Precursor.Quantity[which(D3$Stripped.Sequence == Dat$sequence[i])])
}
rm(i)
rm(D3)
gc()

#4
D4 <- read_tsv("4_KRUK_output_20210401.tsv")
D4 <- D4[,c("Stripped.Sequence","Precursor.Quantity")]
Median4 <- vector()
for (i in 1:934) {
  Median4[i] <- median(D4$Precursor.Quantity[which(D4$Stripped.Sequence == Dat$sequence[i])])
}
rm(i)
rm(D4)
gc()

#5
D5 <- read_tsv("5_PCXC.tsv")
D5 <- D5[,c("Stripped.Sequence","Precursor.Quantity")]
Median5 <- vector()
for (i in 1:934) {
  Median5[i] <- median(D5$Precursor.Quantity[which(D5$Stripped.Sequence == Dat$sequence[i])])
}
rm(i)
rm(D5)
gc()

#6
D6 <- read_tsv("6_OST_output.tsv")
D6 <- D6[,c("Stripped.Sequence","Precursor.Quantity")]
Median6 <- vector()
for (i in 1:934) {
  Median6[i] <- median(D6$Precursor.Quantity[which(D6$Stripped.Sequence == Dat$sequence[i])])
}
rm(i)
rm(D6)
gc()

#7
D7 <- read_tsv("7_PCSHA_output.tsv")
D7 <- D7[,c("Stripped.Sequence","Precursor.Quantity")]
Median7 <- vector()
for (i in 1:934) {
  Median7[i] <- median(D7$Precursor.Quantity[which(D7$Stripped.Sequence == Dat$sequence[i])])
}
rm(i)
rm(D7)
gc()

DR <- c(sort(Median1, decreasing = T), sort(Median2, decreasing = T), sort(Median3, decreasing = T), sort(Median4, decreasing = T), sort(Median5, decreasing = T), sort(Median6, decreasing = T), sort(Median7, decreasing = T))
DR <- log10(DR)
rm(Median1, Median2, Median3, Median4, Median5, Median6, Median7)
DR_Dat <- data.frame(DR = DR, Rank = rep(c(1:934), 7), Dataset = rep(c("1_QEHF","2_QEHF","3_QEHF","4_QEHF","5_6600","6_5600+","7_timsTOF Pro"), each = 934))
rm(DR)

library(ggrepel)
library(ggsci)
ggplot(DR_Dat, aes(x = Rank, y = DR, fill = Dataset, color = Dataset)) +
  geom_line(size = 2)+
  theme_classic() +
  scale_color_nejm() +
  scale_fill_nejm() +
  scale_x_continuous(breaks = c(0,150,300,450,600,750,900)) +
  scale_y_continuous(breaks = c(0,1.5,3,4.5,6,7.5,9)) +
  theme(axis.title.x = element_text(size = 17), axis.title.y = element_text(size = 17)) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(axis.text.x = element_text(size = 14, color = "black"), axis.text.y = element_text(size = 14, color = "black")) +
  labs(x = "", y = "log10(Precursor intensity)")

rm(DR_Dat)

#Retention Time

#1
D1 <- read_tsv("1_QEHF1_TPD_A_output.tsv")
D1 <- D1[,c("Stripped.Sequence","RT")]
Median1 <- vector()
for (i in 1:934) {
  Median1[i] <- median(D1$RT[which(D1$Stripped.Sequence == Dat$sequence[i])])
}
rm(i)
rm(D1)
gc()

#2
D2 <- read_tsv("2_QEHF1_TPD_B_output.tsv")
D2 <- D2[,c("Stripped.Sequence","RT")]
Median2 <- vector()
for (i in 1:934) {
  Median2[i] <- median(D2$RT[which(D2$Stripped.Sequence == Dat$sequence[i])])
}
rm(i)
rm(D2)
gc()

#3
D3 <- read_tsv("3_TPD_C_output.tsv")
D3 <- D3[,c("Stripped.Sequence","RT")]
Median3 <- vector()
for (i in 1:934) {
  Median3[i] <- median(D3$RT[which(D3$Stripped.Sequence == Dat$sequence[i])])
}
rm(i)
rm(D3)
gc()

#4
D4 <- read_tsv("4_KRUK_output_20210401.tsv")
D4 <- D4[,c("Stripped.Sequence","RT")]
Median4 <- vector()
for (i in 1:934) {
  Median4[i] <- median(D4$RT[which(D4$Stripped.Sequence == Dat$sequence[i])])
}
rm(i)
rm(D4)
gc()

#5
D5 <- read_tsv("5_PCXC.tsv")
D5 <- D5[,c("Stripped.Sequence","RT")]
Median5 <- vector()
for (i in 1:934) {
  Median5[i] <- median(D5$RT[which(D5$Stripped.Sequence == Dat$sequence[i])])
}
rm(i)
rm(D5)
gc()

#6
D6 <- read_tsv("6_OST_output.tsv")
D6 <- D6[,c("Stripped.Sequence","RT")]
Median6 <- vector()
for (i in 1:934) {
  Median6[i] <- median(D6$RT[which(D6$Stripped.Sequence == Dat$sequence[i])])
}
rm(i)
rm(D6)
gc()

#7
D7 <- read_tsv("7_PCSHA_output.tsv")
D7 <- D7[,c("Stripped.Sequence","RT")]
Median7 <- vector()
for (i in 1:934) {
  Median7[i] <- median(D7$RT[which(D7$Stripped.Sequence == Dat$sequence[i])])
}
rm(i)
rm(D7)
gc()

RT <- c(sort(Median1), sort(Median2), sort(Median3), sort(Median4), sort(Median5), sort(Median6), sort(Median7))
rm(Median1, Median2, Median3, Median4, Median5, Median6, Median7)
RT_Dat <- data.frame(RT = RT, Rank = rep(c(1:934), 7), Dataset = rep(c("1_QEHF","2_QEHF","3_QEHF","4_QEHF","5_6600","6_5600+","7_timsTOF Pro"), each = 934))
rm(RT)

library(ggrepel)
library(ggsci)
ggplot(RT_Dat, aes(x = Rank, y = RT, fill = Dataset, color = Dataset)) +
  geom_line(size = 2) +
  theme_classic() +
  scale_color_nejm() +
  scale_fill_nejm() +
  scale_x_continuous(breaks = c(0,150,300,450,600,750,900)) +
  scale_y_continuous(breaks = c(0,10,20,30,40,50,60,70)) +
  theme(axis.title.x = element_text(size = 17), axis.title.y = element_text(size = 17)) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(axis.text.x = element_text(size = 14, color = "black"), axis.text.y = element_text(size = 14, color = "black")) +
  labs(x = "", y = "Retention time")

rm(RT_Dat)
rm(Dat)
gc()
