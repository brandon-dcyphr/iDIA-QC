#Overview Heatmap

#Data Loading
library(tidyverse)
File_Info <- read_csv("DIAQC_2638_RunID_Runname_WH.csv")

#Protein Number Statistics
Prot_Number_Stat <- vector()

#R

#Contamination
Lib_R <- read_tsv("20191030CRDD_Vlib_highpH_SCX_108runs.tsv")
Lib_R <- Lib_R[,c(24,26)]
Lib_R <- Lib_R[match(na.omit(unique(Lib_R$ProteinGroups)), Lib_R$ProteinGroups),]
Con_Prot_R <- which(grepl("MOUSE", Lib_R$`Protein Name`, fixed = TRUE) == FALSE)
Con_Prot_R <- Lib_R$ProteinGroups[Con_Prot_R]
rm(Lib_R)

#Combination
a <- read_tsv(File_Info$main[1])
a <- a[,c("Protein.Group","PG.Quantity")]
a <- a[match(na.omit(unique(a$Protein.Group)), a$Protein.Group),]
a <- a[-which(a$Protein.Group %in% Con_Prot_R),]
Prot_Number_Stat[1] <- nrow(a)
a <- a %>% column_to_rownames("Protein.Group")
colnames(a) <- File_Info$Run_ID[1]
a <- as.data.frame(t(a))

Index_R <- setdiff(which(substr(File_Info$Instrument_ID, 1, 1) == "R"), 1)

for (i in Index_R) {
  b <- read_tsv(File_Info$main[i], show_col_types = FALSE)
  b <- b[,c("Protein.Group","PG.Quantity")]
  b <- b[match(na.omit(unique(b$Protein.Group)), b$Protein.Group),]
  b <- b[setdiff(1:nrow(b), which(b$Protein.Group %in% Con_Prot_R)),]
  Prot_Number_Stat[i] <- nrow(b)
  b <- b %>% column_to_rownames("Protein.Group")
  colnames(b) <- File_Info$Run_ID[i]
  a <- bind_rows(a, as.data.frame(t(b)))
  print(i)
}
rm(i, b)
rm(Con_Prot_R, Index_R)

#D

#Contamination
Lib_D <- read_tsv("library.tsv")
Lib_D <- Lib_D[match(na.omit(unique(Lib_D$ProteinId)), Lib_D$ProteinId),]
write.csv(Lib_D$ProteinId, "Lib_D_Uniprot.csv")

#Uniprot Annotation
Lib_D_EN <- read_tsv("Lib_D_Uniprot_EntryName.tsv")
Lib_D$EntryName <- Lib_D_EN$EntryName
rm(Lib_D_EN)
Lib_D <- Lib_D[,c(4,16)]
Con_Prot_D <- which(grepl("MOUSE", Lib_D$EntryName, fixed = TRUE) == FALSE)
rm(Lib_D, Con_Prot_D)

#Combination
Index_D <- which(substr(File_Info$Instrument_ID, 1, 1) == "D")

for (i in Index_D) {
  b <- read_tsv(File_Info$main[i], show_col_types = FALSE)
  b <- b[,c("Protein.Group","PG.Quantity")]
  b <- b[match(na.omit(unique(b$Protein.Group)), b$Protein.Group),]
  Prot_Number_Stat[i] <- nrow(b)
  b <- b %>% column_to_rownames("Protein.Group")
  colnames(b) <- File_Info$Run_ID[i]
  a <- bind_rows(a, as.data.frame(t(b)))
  print(i)
}
rm(i, b)
rm(Index_D)

#W

#Contamination
Lib_W <- read_tsv("Library_FinalPanMouse_v2_FinalWithoutDecoys.tsv")
Lib_W <- Lib_W[match(na.omit(unique(Lib_W$ProteinName)), Lib_W$ProteinName),]

#Select the contamination by myself
Con_Prot_W <- c("1/iRT_protein","1/sp|Q3SZR3|A1AG_BOVIN","1/sp|Q58D62|FETUB_BOVIN","2/sp|O35522|PSB9_MUSMB/sp|P28076")
rm(Lib_W)

#Combination
Index_W <- setdiff(which(substr(File_Info$Instrument_ID, 1, 1) == "W"), 1)

for (i in Index_W) {
  b <- read_tsv(File_Info$main[i], show_col_types = FALSE)
  b <- b[,c("Protein.Group","PG.Quantity")]
  b <- b[match(na.omit(unique(b$Protein.Group)), b$Protein.Group),]
  b <- b[setdiff(1:nrow(b), which(b$Protein.Group %in% Con_Prot_W)),]
  Prot_Number_Stat[i] <- nrow(b)
  c <- strsplit(b$Protein.Group, "/sp|", fixed = T)
  d <- vector()
  for (j in 1:length(c)) {
    d[j] <- paste(c[[j]], collapse = ";")
  }
  rm(j)
  d <- substring(d, 3)
  b$Protein.Group <- d
  b <- b %>% column_to_rownames("Protein.Group")
  colnames(b) <- File_Info$Run_ID[i]
  a <- bind_rows(a, as.data.frame(t(b)))
  print(i)
}
rm(i, b, c, d)
rm(Index_W, Con_Prot_W)

colnames(a)[which(substr(colnames(a), 1, 1) == ";")] <- substring(colnames(a)[which(substr(colnames(a), 1, 1) == ";")], 2)

#Sorting
a <- a[File_Info$Run_ID,]

#Box Plot
File_Info$Protein_Number <- Prot_Number_Stat
rm(Prot_Number_Stat)
File_Info$Instrument_Type <- substring(File_Info$Instrument_ID, 1, 1)

for(i in c("W03","W06","W07","W14","R01","R02","R04","R05","R08","R09","R11","R12","R15","R20","D10","D13","D16","D17")){
  print(median(File_Info$Protein_Number[File_Info$Instrument_ID == i]))
}
rm(i)

ggplot(data = File_Info, aes(x = Instrument_ID, y = Protein_Number, fill = Instrument_Type)) +
  geom_boxplot(size = 1, outlier.size = 0.5) +
  theme_classic() +
  scale_x_discrete(limits = c("W03","W06","W07","W14","R01","R02","R04","R05","R08","R09","R11","R12","R15","R18","R19","R20","R21","D10","D13","D16","D17")) +
  scale_y_continuous(breaks = seq(0,7000,1000)) +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 14, color = "black"), axis.text.y = element_text(size = 14, color = "black")) +
  theme(legend.text = element_text(size = 15), legend.title = element_text(size = 15)) +
  theme(plot.title = element_text(size = 15, face = "bold")) +
  labs(y = "The number of identified protein", x = "Instrument ID")

#Overview Heatmap
a[is.na(a)] <- 0

unique(File_Info$Instrument_ID)
length(unique(File_Info$Instrument_ID))

ZeroOneNormalization <- function(ProtMatrix){
  ColMax <- vector()
  for (j in 1:ncol(ProtMatrix)) {
    ColMax[j] <- max(ProtMatrix[,j])
  }
  rm(j)
  for (m in setdiff(1:ncol(ProtMatrix), which(ColMax == 0))) {
    for (n in 1:nrow(ProtMatrix)) {
      ProtMatrix[n,m] <- (ProtMatrix[n,m])/(ColMax[m])
    }
  }
  rm(m, n, ColMax)
  return(ProtMatrix)
}

a_R01 <- a[which(File_Info$Instrument_ID == "R01"),]
a_R01 <- ZeroOneNormalization(a_R01)

a_D10 <- a[which(File_Info$Instrument_ID == "D10"),]
a_D10 <- ZeroOneNormalization(a_D10)

a_R11 <- a[which(File_Info$Instrument_ID == "R11"),]
a_R11 <- ZeroOneNormalization(a_R11)

a_R12 <- a[which(File_Info$Instrument_ID == "R12"),]
a_R12 <- ZeroOneNormalization(a_R12)

a_D13 <- a[which(File_Info$Instrument_ID == "D13"),]
a_D13 <- ZeroOneNormalization(a_D13)

a_W14 <- a[which(File_Info$Instrument_ID == "W14"),]
a_W14 <- ZeroOneNormalization(a_W14)

a_R15 <- a[which(File_Info$Instrument_ID == "R15"),]
a_R15 <- ZeroOneNormalization(a_R15)

a_D16 <- a[which(File_Info$Instrument_ID == "D16"),]
a_D16 <- ZeroOneNormalization(a_D16)

a_R02 <- a[which(File_Info$Instrument_ID == "R02"),]
a_R02 <- ZeroOneNormalization(a_R02)

a_R20 <- a[which(File_Info$Instrument_ID == "R20"),]
a_R20 <- ZeroOneNormalization(a_R20)

a_W03 <- a[which(File_Info$Instrument_ID == "W03"),]
a_W03 <- ZeroOneNormalization(a_W03)

a_R04 <- a[which(File_Info$Instrument_ID == "R04"),]
a_R04 <- ZeroOneNormalization(a_R04)

a_R05 <- a[which(File_Info$Instrument_ID == "R05"),]
a_R05 <- ZeroOneNormalization(a_R05)

a_W06 <- a[which(File_Info$Instrument_ID == "W06"),]
a_W06 <- ZeroOneNormalization(a_W06)

a_W07 <- a[which(File_Info$Instrument_ID == "W07"),]
a_W07 <- ZeroOneNormalization(a_W07)

a_R08 <- a[which(File_Info$Instrument_ID == "R08"),]
a_R08 <- ZeroOneNormalization(a_R08)

a_R09 <- a[which(File_Info$Instrument_ID == "R09"),]
a_R09 <- ZeroOneNormalization(a_R09)

a_D17 <- a[which(File_Info$Instrument_ID == "D17"),]
a_D17 <- ZeroOneNormalization(a_D17)

a_R18 <- a[which(File_Info$Instrument_ID == "R18"),]
a_R18 <- ZeroOneNormalization(a_R18)

a_R19 <- a[which(File_Info$Instrument_ID == "R19"),]
a_R19 <- ZeroOneNormalization(a_R19)

a_R21 <- a[which(File_Info$Instrument_ID == "R21"),]
a_R21 <- ZeroOneNormalization(a_R21)

a_scaled <- as.data.frame(rbind(a_W03, a_W06, a_W07, a_W14, a_R01, a_R02, a_R04, a_R05, a_R08, a_R09, a_R11, a_R12, a_R15, a_R18, a_R19, a_R20, a_R21, a_D10, a_D13, a_D16, a_D17))
rm(a_D10, a_D13, a_D16, a_D17, a_R01, a_R02, a_R04, a_R05, a_R08, a_R09, a_R11, a_R12, a_R15, a_R18, a_R19, a_R20, a_R21, a_W03, a_W06, a_W07, a_W14)
rm(ZeroOneNormalization)

#Heatmap
library(pheatmap)
library(RColorBrewer)
anno_col <- data.frame(Instrument = File_Info$Instrument_ID)
rownames(anno_col) <- File_Info$Run_ID
mycolors <- brewer.pal(11, "RdYlBu")
mycolors <- mycolors[1:6]
bk <- unique(c(seq(0,1, length = 1000)))
pheatmap(t(a_scaled),
         breaks = bk,
         scale = "none",
         fontsize = 9,
         color = colorRampPalette(rev(mycolors))(1000),
         annotation_col = anno_col,
         annotation_colors = list(Instrument = c(W03 = "#BB0021FF", W06 = "#808180FF", W07 = "#1B1919FF", W14 = "#B09C85FF", R01 = "#E64B35FF", R02 = "#631879FF", R04 = "#5F559BFF", R05 = "#A20056FF", R08 = "#BC3C29FF", R09 = "#0072B5FF", R11 = "#EFC000FF", R12 = "#8491B4FF", R15 = "#FC719EFF", R18 = "#843C39FF", R19 = "#17BECFFF", R20 = "#E7CB94FF", R21 = "#8F7700FF", D10 = "#00A087FF", D13 = "#7E6148FF", D16 = "#008B45FF", D17 = "#E18727FF")),
         clustering_method ="single",
         show_rownames = F, show_colnames = F, 
         width = 30, height = 15,
         cluster_cols = FALSE)
rm(anno_col)
rm(bk)
rm(mycolors)

#Time
File_Info2 <- as.data.frame(read_csv("2_DIAQC2435_203_acquisition_time_20221204_2223.csv"))
rownames(File_Info2) <- File_Info2$Run_ID
File_Info2 <- File_Info2[File_Info$Run_ID,]
File_Info <- as.data.frame(File_Info)
rownames(File_Info) <- File_Info$Run_ID
File_Info <- File_Info[rownames(a_scaled),]
File_Info2 <- File_Info2[rownames(a_scaled),]

#t-SNE
set.seed(1)
library(tsne)
tsne <- tsne(a_scaled)
tsne <- as.data.frame(tsne)
tsne <- as.data.frame(cbind(tsne, Instrument = File_Info$Instrument_ID))
tsne$Instrument <- as.factor(tsne$Instrument)
ggplot(tsne, aes(x = V1, y = V2, color = Instrument, fill = Instrument)) +
  geom_point(size = 1, alpha = 1) +
  scale_color_manual(values = c("#00A087FF","#7E6148FF","#008B45FF","#E18727FF","#E64B35FF","#631879FF","#5F559BFF","#A20056FF","#BC3C29FF","#0072B5FF","#EFC000FF","#8491B4FF","#FC719EFF","#843C39FF","#7876B1FF","#E7CB94FF","#8F7700FF","#BB0021FF","#808180FF","#1B1919FF","#B09C85FF")) +
  theme_classic() +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 13, color = "black"), axis.text.y = element_text(size = 13, color = "black")) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(legend.text = element_text(size = 14)) +
  labs(x = "t-SNE1", y = "t-SNE2")
rm(tsne)

library(RColorBrewer)

#W03
set.seed(1)
library(tsne)
tsne <- tsne(a_scaled[which(File_Info$Instrument_ID == "W03"),])
tsne <- as.data.frame(tsne)
tsne <- as.data.frame(cbind(tsne, Time = File_Info2$DATE2[which(File_Info$Instrument_ID == "W03")] - min(File_Info2$DATE2[which(File_Info$Instrument_ID == "W03")])))
g1 <- ggplot(tsne,  aes(x = V1,  y = V2, color = Time)) +
  geom_point(size = 1.5, alpha = 1) +
  scale_color_gradientn(colors = rev(brewer.pal(11, "RdYlBu"))) +
  theme_classic() +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 13, color = "black"), axis.text.y = element_text(size = 13, color = "black")) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(legend.text = element_text(size = 14)) +
  labs(x = "t-SNE1", y = "t-SNE2") +
  ggtitle("W03")
rm(tsne)

#W06
set.seed(1)
library(tsne)
tsne <- tsne(a_scaled[which(File_Info$Instrument_ID == "W06"),])
tsne <- as.data.frame(tsne)
tsne <- as.data.frame(cbind(tsne, Time = File_Info2$DATE2[which(File_Info$Instrument_ID == "W06")] - min(File_Info2$DATE2[which(File_Info$Instrument_ID == "W06")])))
g2 <- ggplot(tsne,  aes(x = V1,  y = V2, color = Time)) +
  geom_point(size = 1.5, alpha = 1) +
  scale_color_gradientn(colors = rev(brewer.pal(11, "RdYlBu"))) +
  theme_classic() +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 13, color = "black"), axis.text.y = element_text(size = 13, color = "black")) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(legend.text = element_text(size = 14)) +
  labs(x = "t-SNE1", y = "t-SNE2") +
  ggtitle("W06")
rm(tsne)

#W07
set.seed(1)
library(tsne)
tsne <- tsne(a_scaled[which(File_Info$Instrument_ID == "W07"),])
tsne <- as.data.frame(tsne)
tsne <- as.data.frame(cbind(tsne, Time = File_Info2$DATE2[which(File_Info$Instrument_ID == "W07")] - min(File_Info2$DATE2[which(File_Info$Instrument_ID == "W07")])))
g3 <- ggplot(tsne,  aes(x = V1,  y = V2, color = Time)) +
  geom_point(size = 1.5, alpha = 1) +
  scale_color_gradientn(colors = rev(brewer.pal(11, "RdYlBu"))) +
  theme_classic() +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 13, color = "black"), axis.text.y = element_text(size = 13, color = "black")) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(legend.text = element_text(size = 14)) +
  labs(x = "t-SNE1", y = "t-SNE2") +
  ggtitle("W07")
rm(tsne)

#W14
set.seed(1)
library(tsne)
tsne <- tsne(a_scaled[which(File_Info$Instrument_ID == "W14"),])
tsne <- as.data.frame(tsne)
tsne <- as.data.frame(cbind(tsne, Time = File_Info2$DATE2[which(File_Info$Instrument_ID == "W14")] - min(File_Info2$DATE2[which(File_Info$Instrument_ID == "W14")])))
g4 <- ggplot(tsne,  aes(x = V1,  y = V2, color = Time)) +
  geom_point(size = 1.5, alpha = 1) +
  scale_color_gradientn(colors = rev(brewer.pal(11, "RdYlBu"))) +
  theme_classic() +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 13, color = "black"), axis.text.y = element_text(size = 13, color = "black")) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(legend.text = element_text(size = 14)) +
  labs(x = "t-SNE1", y = "t-SNE2") +
  ggtitle("W14")
rm(tsne)

#R01
set.seed(1)
library(tsne)
tsne <- tsne(a_scaled[which(File_Info$Instrument_ID == "R01"),])
tsne <- as.data.frame(tsne)
tsne <- as.data.frame(cbind(tsne, Time = File_Info2$DATE2[which(File_Info$Instrument_ID == "R01")] - min(File_Info2$DATE2[which(File_Info$Instrument_ID == "R01")])))
g5 <- ggplot(tsne,  aes(x = V1,  y = V2, color = Time)) +
  geom_point(size = 1.5, alpha = 1) +
  scale_color_gradientn(colors = rev(brewer.pal(11, "RdYlBu"))) +
  theme_classic() +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 13, color = "black"), axis.text.y = element_text(size = 13, color = "black")) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(legend.text = element_text(size = 14)) +
  labs(x = "t-SNE1", y = "t-SNE2") +
  ggtitle("R01")
rm(tsne)

#R02
set.seed(1)
library(tsne)
tsne <- tsne(a_scaled[which(File_Info$Instrument_ID == "R02"),])
tsne <- as.data.frame(tsne)
tsne <- as.data.frame(cbind(tsne, Time = File_Info2$DATE2[which(File_Info$Instrument_ID == "R02")] - min(File_Info2$DATE2[which(File_Info$Instrument_ID == "R02")])))
g6 <- ggplot(tsne,  aes(x = V1,  y = V2, color = Time)) +
  geom_point(size = 1.5, alpha = 1) +
  scale_color_gradientn(colors = rev(brewer.pal(11, "RdYlBu"))) +
  theme_classic() +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 13, color = "black"), axis.text.y = element_text(size = 13, color = "black")) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(legend.text = element_text(size = 14)) +
  labs(x = "t-SNE1", y = "t-SNE2") +
  ggtitle("R02")
rm(tsne)

#R04
set.seed(1)
library(tsne)
tsne <- tsne(a_scaled[which(File_Info$Instrument_ID == "R04"),])
tsne <- as.data.frame(tsne)
tsne <- as.data.frame(cbind(tsne, Time = File_Info2$DATE2[which(File_Info$Instrument_ID == "R04")] - min(File_Info2$DATE2[which(File_Info$Instrument_ID == "R04")])))
g7 <- ggplot(tsne,  aes(x = V1,  y = V2, color = Time)) +
  geom_point(size = 1.5, alpha = 1) +
  scale_color_gradientn(colors = rev(brewer.pal(11, "RdYlBu"))) +
  theme_classic() +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 13, color = "black"), axis.text.y = element_text(size = 13, color = "black")) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(legend.text = element_text(size = 14)) +
  labs(x = "t-SNE1", y = "t-SNE2") +
  ggtitle("R04")
rm(tsne)

#R05
set.seed(1)
library(tsne)
tsne <- tsne(a_scaled[which(File_Info$Instrument_ID == "R05"),])
tsne <- as.data.frame(tsne)
tsne <- as.data.frame(cbind(tsne, Time = File_Info2$DATE2[which(File_Info$Instrument_ID == "R05")] - min(File_Info2$DATE2[which(File_Info$Instrument_ID == "R05")])))
g8 <- ggplot(tsne,  aes(x = V1,  y = V2, color = Time)) +
  geom_point(size = 1.5, alpha = 1) +
  scale_color_gradientn(colors = rev(brewer.pal(11, "RdYlBu"))) +
  theme_classic() +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 13, color = "black"), axis.text.y = element_text(size = 13, color = "black")) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(legend.text = element_text(size = 14)) +
  labs(x = "t-SNE1", y = "t-SNE2") +
  ggtitle("R05")
rm(tsne)

#R08
set.seed(1)
library(tsne)
tsne <- tsne(a_scaled[which(File_Info$Instrument_ID == "R08"),])
tsne <- as.data.frame(tsne)
tsne <- as.data.frame(cbind(tsne, Time = File_Info2$DATE2[which(File_Info$Instrument_ID == "R08")] - min(File_Info2$DATE2[which(File_Info$Instrument_ID == "R08")])))
g9 <- ggplot(tsne,  aes(x = V1,  y = V2, color = Time)) +
  geom_point(size = 1.5, alpha = 1) +
  scale_color_gradientn(colors = rev(brewer.pal(11, "RdYlBu"))) +
  theme_classic() +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 13, color = "black"), axis.text.y = element_text(size = 13, color = "black")) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(legend.text = element_text(size = 14)) +
  labs(x = "t-SNE1", y = "t-SNE2") +
  ggtitle("R08")
rm(tsne)

#R09
set.seed(1)
library(tsne)
tsne <- tsne(a_scaled[which(File_Info$Instrument_ID == "R09"),])
tsne <- as.data.frame(tsne)
tsne <- as.data.frame(cbind(tsne, Time = File_Info2$DATE2[which(File_Info$Instrument_ID == "R09")] - min(File_Info2$DATE2[which(File_Info$Instrument_ID == "R09")])))
g10 <- ggplot(tsne,  aes(x = V1,  y = V2, color = Time)) +
  geom_point(size = 1.5, alpha = 1) +
  scale_color_gradientn(colors = rev(brewer.pal(11, "RdYlBu"))) +
  theme_classic() +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 13, color = "black"), axis.text.y = element_text(size = 13, color = "black")) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(legend.text = element_text(size = 14)) +
  labs(x = "t-SNE1", y = "t-SNE2") +
  ggtitle("R09")
rm(tsne)

#R11
set.seed(1)
library(tsne)
tsne <- tsne(a_scaled[which(File_Info$Instrument_ID == "R11"),])
tsne <- as.data.frame(tsne)
tsne <- as.data.frame(cbind(tsne, Time = File_Info2$DATE2[which(File_Info$Instrument_ID == "R11")] - min(File_Info2$DATE2[which(File_Info$Instrument_ID == "R11")])))
g11 <- ggplot(tsne,  aes(x = V1,  y = V2, color = Time)) +
  geom_point(size = 1.5, alpha = 1) +
  scale_color_gradientn(colors = rev(brewer.pal(11, "RdYlBu"))) +
  theme_classic() +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 13, color = "black"), axis.text.y = element_text(size = 13, color = "black")) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(legend.text = element_text(size = 14)) +
  labs(x = "t-SNE1", y = "t-SNE2") +
  ggtitle("R11")
rm(tsne)

#R12
set.seed(1)
library(tsne)
tsne <- tsne(a_scaled[which(File_Info$Instrument_ID == "R12"),])
tsne <- as.data.frame(tsne)
tsne <- as.data.frame(cbind(tsne, Time = File_Info2$DATE2[which(File_Info$Instrument_ID == "R12")] - min(File_Info2$DATE2[which(File_Info$Instrument_ID == "R12")])))
g12 <- ggplot(tsne,  aes(x = V1,  y = V2, color = Time)) +
  geom_point(size = 1.5, alpha = 1) +
  scale_color_gradientn(colors = rev(brewer.pal(11, "RdYlBu"))) +
  theme_classic() +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 13, color = "black"), axis.text.y = element_text(size = 13, color = "black")) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(legend.text = element_text(size = 14)) +
  labs(x = "t-SNE1", y = "t-SNE2") +
  ggtitle("R12")
rm(tsne)

#R15
set.seed(1)
library(tsne)
tsne <- tsne(a_scaled[which(File_Info$Instrument_ID == "R15"),])
tsne <- as.data.frame(tsne)
tsne <- as.data.frame(cbind(tsne, Time = File_Info2$DATE2[which(File_Info$Instrument_ID == "R15")] - min(File_Info2$DATE2[which(File_Info$Instrument_ID == "R15")])))
g13 <- ggplot(tsne, aes(x=V1, y=V2,color=Time)) +
  geom_point(size = 1.5, alpha = 1) +
  scale_color_gradientn(colors = rev(brewer.pal(11, "RdYlBu"))) +
  theme_classic() +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 13, color = "black"), axis.text.y = element_text(size = 13, color = "black")) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(legend.text = element_text(size = 14)) +
  labs(x = "t-SNE1", y = "t-SNE2") +
  ggtitle("R15")
rm(tsne)

#R18
set.seed(1)
library(tsne)
tsne <- tsne(a_scaled[which(File_Info$Instrument_ID == "R18"),])
tsne <- as.data.frame(tsne)
tsne <- as.data.frame(cbind(tsne, Time = File_Info2$DATE2[which(File_Info$Instrument_ID == "R18")] - min(File_Info2$DATE2[which(File_Info$Instrument_ID == "R18")])))
g14 <- ggplot(tsne,  aes(x = V1,  y = V2, color = Time)) +
  geom_point(size = 1.5, alpha = 1) +
  scale_color_gradientn(colors = rev(brewer.pal(11, "RdYlBu"))) +
  theme_classic() +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 13, color = "black"), axis.text.y = element_text(size = 13, color = "black")) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(legend.text = element_text(size = 14)) +
  labs(x = "t-SNE1", y = "t-SNE2") +
  ggtitle("R18")
rm(tsne)

#R19
set.seed(1)
library(tsne)
tsne <- tsne(a_scaled[which(File_Info$Instrument_ID == "R19"),])
tsne <- as.data.frame(tsne)
tsne <- as.data.frame(cbind(tsne, Time = File_Info2$DATE2[which(File_Info$Instrument_ID == "R19")] - min(File_Info2$DATE2[which(File_Info$Instrument_ID == "R19")])))
g15 <- ggplot(tsne,  aes(x = V1,  y = V2, color = Time)) +
  geom_point(size = 1.5, alpha = 1) +
  scale_color_gradientn(colors = rev(brewer.pal(11, "RdYlBu"))) +
  theme_classic() +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 13, color = "black"), axis.text.y = element_text(size = 13, color = "black")) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(legend.text = element_text(size = 14)) +
  labs(x = "t-SNE1", y = "t-SNE2") +
  ggtitle("R19")
rm(tsne)

#R20
set.seed(1)
library(tsne)
tsne <- tsne(a_scaled[which(File_Info$Instrument_ID == "R20"),])
tsne <- as.data.frame(tsne)
tsne <- as.data.frame(cbind(tsne, Time = File_Info2$DATE2[which(File_Info$Instrument_ID == "R20")] - min(File_Info2$DATE2[which(File_Info$Instrument_ID == "R20")])))
g16 <- ggplot(tsne,  aes(x = V1,  y = V2, color = Time)) +
  geom_point(size = 1.5, alpha = 1) +
  scale_color_gradientn(colors = rev(brewer.pal(11, "RdYlBu"))) +
  theme_classic() +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 13, color = "black"), axis.text.y = element_text(size = 13, color = "black")) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(legend.text = element_text(size = 14)) +
  labs(x = "t-SNE1", y = "t-SNE2") +
  ggtitle("R20")
rm(tsne)

#R21
set.seed(1)
library(tsne)
tsne <- tsne(a_scaled[which(File_Info$Instrument_ID == "R21"),])
tsne <- as.data.frame(tsne)
tsne <- as.data.frame(cbind(tsne, Time = File_Info2$DATE2[which(File_Info$Instrument_ID == "R21")] - min(File_Info2$DATE2[which(File_Info$Instrument_ID == "R21")])))
g17 <- ggplot(tsne,  aes(x = V1,  y = V2, color = Time)) +
  geom_point(size = 1.5, alpha = 1) +
  scale_color_gradientn(colors = rev(brewer.pal(11, "RdYlBu"))) +
  theme_classic() +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 13, color = "black"), axis.text.y = element_text(size = 13, color = "black")) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(legend.text = element_text(size = 14)) +
  labs(x = "t-SNE1", y = "t-SNE2") +
  ggtitle("R21")
rm(tsne)

#D10
set.seed(1)
library(tsne)
tsne <- tsne(a_scaled[which(File_Info$Instrument_ID == "D10"),])
tsne <- as.data.frame(tsne)
tsne <- as.data.frame(cbind(tsne, Time = File_Info2$DATE2[which(File_Info$Instrument_ID == "D10")] - min(File_Info2$DATE2[which(File_Info$Instrument_ID == "D10")])))
g18 <- ggplot(tsne,  aes(x = V1,  y = V2, color = Time)) +
  geom_point(size = 1.5, alpha = 1) +
  scale_color_gradientn(colors = rev(brewer.pal(11, "RdYlBu"))) +
  theme_classic() +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 13, color = "black"), axis.text.y = element_text(size = 13, color = "black")) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(legend.text = element_text(size = 14)) +
  labs(x = "t-SNE1", y = "t-SNE2") +
  ggtitle("D10")
rm(tsne)

#D13
set.seed(1)
library(tsne)
tsne <- tsne(a_scaled[which(File_Info$Instrument_ID == "D13"),])
tsne <- as.data.frame(tsne)
tsne <- as.data.frame(cbind(tsne, Time = File_Info2$DATE2[which(File_Info$Instrument_ID == "D13")] - min(File_Info2$DATE2[which(File_Info$Instrument_ID == "D13")])))
g19 <- ggplot(tsne,  aes(x = V1,  y = V2, color = Time)) +
  geom_point(size = 1.5, alpha = 1) +
  scale_color_gradientn(colors = rev(brewer.pal(11, "RdYlBu"))) +
  theme_classic() +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 13, color = "black"), axis.text.y = element_text(size = 13, color = "black")) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(legend.text = element_text(size = 14)) +
  labs(x = "t-SNE1", y = "t-SNE2") +
  ggtitle("D13")
rm(tsne)

#D16
set.seed(1)
library(tsne)
tsne <- tsne(a_scaled[which(File_Info$Instrument_ID == "D16"),])
tsne <- as.data.frame(tsne)
tsne <- as.data.frame(cbind(tsne, Time = File_Info2$DATE2[which(File_Info$Instrument_ID == "D16")] - min(File_Info2$DATE2[which(File_Info$Instrument_ID == "D16")])))
g20 <- ggplot(tsne,  aes(x = V1,  y = V2, color = Time)) +
  geom_point(size = 1.5, alpha = 1) +
  scale_color_gradientn(colors = rev(brewer.pal(11, "RdYlBu"))) +
  theme_classic() +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 13, color = "black"), axis.text.y = element_text(size = 13, color = "black")) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(legend.text = element_text(size = 14)) +
  labs(x = "t-SNE1", y = "t-SNE2") +
  ggtitle("D16")
rm(tsne)

#D17
set.seed(1)
library(tsne)
tsne <- tsne(a_scaled[which(File_Info$Instrument_ID == "D17"),])
tsne <- as.data.frame(tsne)
tsne <- as.data.frame(cbind(tsne, Time = File_Info2$DATE2[which(File_Info$Instrument_ID == "D17")] - min(File_Info2$DATE2[which(File_Info$Instrument_ID == "D17")])))
g21 <- ggplot(tsne,  aes(x = V1,  y = V2, color = Time)) +
  geom_point(size = 1.5, alpha = 1) +
  scale_color_gradientn(colors = rev(brewer.pal(11, "RdYlBu"))) +
  theme_classic() +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 13, color = "black"), axis.text.y = element_text(size = 13, color = "black")) +
  theme(legend.text = element_text(size = 14), legend.title = element_text(size = 14)) +
  theme(legend.text = element_text(size = 14)) +
  labs(x = "t-SNE1", y = "t-SNE2") +
  ggtitle("D17")
rm(tsne)

library(patchwork)
g1 + g2 + g3 + g4 + g5 + g6 + g7 + g8 + g9 + g10 + g11 + g12 + g13 + g14 + g15 + g16 + g17 + g18 + g19 + g20 + g21 + plot_layout(ncol = 4)
rm(g1, g2, g3, g4, g5, g6, g7, g8, g9, g10, g11, g12, g13, g14, g15, g16, g17, g18, g19, g20, g21)

rm(a, a_scaled, File_Info, File_Info2)
gc()
