#Identification

#File List
File <- list.files("DIA-NN_output")

#Protein Number Statistics
Prot_Number_Stat <- vector()
library(tidyverse)
for (i in 1:116) {
  File_Info <- read_tsv(paste0("DIA-NN_output/", File[i]))
  Prot_Number_Stat[i] <- length(unique(File_Info$Protein.Ids))
}
rm(File_Info)
rm(i)
rm(File)
summary(Prot_Number_Stat)

#Boxplot
library(ggplot2)
set.seed(1)
ggplot(data = data.frame(Prot_Number_Stat, Class = rep("", 116)), aes(x = Class, y = Prot_Number_Stat)) +
  geom_boxplot(size = 1, outlier.size = 1, fill = "pink", color = "black") +
  geom_jitter(size = 1.5) +
  theme_bw() +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 14, color = "black"), axis.text.y = element_text(size = 14, color = "black")) +
  theme(legend.text = element_text(size = 15), legend.title = element_text(size = 15)) +
  theme(plot.title = element_text(size = 15, face = "bold")) +
  labs(y = "Number of identified proteins", x = "") +
  ggtitle("New test set")
rm(Prot_Number_Stat)
