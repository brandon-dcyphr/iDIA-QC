#Observed Agreement 11 paired samples

#Data Loading
library(tidyverse)
library(irr)

TechRep <- read_csv("TechRep_modified.csv")
Dat <- read_csv("DIAQC_2638_Label_17features_21raters_2groups_gaohh20221221-1640.csv")
Dat <- Dat[Dat$Run_ID %in% TechRep$Run_ID,]

Agreement <- vector()
for (j in 1:11) {
  Dat1 <- Dat[Dat$Run_ID %in% TechRep$Run_ID[(2*j - 1):(2*j)],]
  Dat1 <- arrange(Dat1, Run_ID, Operator, Feature_ID)
  Index <- unique(Dat1$Operator)
  for (i in 1:length(Index)) {
    A <- Dat1[which(Dat1$Operator == Index[i]),]
    Data <- data.frame(N1 = A$Label[c(1:(nrow(A)/2))], N2 = A$Label[c((nrow(A)/2+1):nrow(A))])
    Agreement <- c(Agreement, agree(Data)$value / 100)
  }
}
rm(i)
rm(j)
rm(Index)
rm(A)
rm(Data)
rm(Dat1)
rm(TechRep)
rm(Dat)

library(ggplot2)
Agreement <- round(Agreement, 2)
df <- as.data.frame(table(Agreement))
ggplot(df, aes(x = Agreement, y = Freq)) +
  geom_bar(stat = "identity", fill = "pink", width = 0.9) +
  theme_bw() +
  theme(panel.grid = element_blank()) +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 14, color = "black"), axis.text.y = element_text(size = 14, color = "black")) +
  labs(x = "Observed agreement", y = "Count") +
  scale_y_continuous(expand = c(0,0)) +
  coord_flip()
rm(df)
rm(Agreement)
gc()
