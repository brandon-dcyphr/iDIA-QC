#Sankey Diagram

#Data Preparation
links <- read.csv("3Instrument_issue20241111V6.csv")
A <- links$source[1:44]
C <- links$source[45:88]
nodes <- data.frame(name = unique(c(links$source, links$target)))

for (i in 1:59) {
  links[which(links == nodes$name[i], arr.ind = T)] <- i - 1
}
links$source <- as.numeric(links$source)
links$target <- as.numeric(links$target)

links$value <- rep(c(0.3, 0.5, 0.7), each = 44)
links$group <- rep(A, 3)
links$group <- as.factor(links$group)
nodes$group <- rep("A", 59)
nodes$group <- as.factor(nodes$group)
str(nodes)
str(links)
my_color <- 'd3.scaleOrdinal().domain(["1Similar proportional decline in MS1 and MS2 signal, Poor identification", "2Decline in MS2 signa and good MS1 signal, poor identification", "3Good MS1 and MS2 signals with poor identification", "4Loss of hydrophilic peptides", "5Loss of hydrophobic peptides", "6Poor peak shape", "7Retention time shift with poor identification", "8Unstable spray", "A"]).range(["#dd92ae", "#bf8383", "#c8d5ff", "#e8d659", "#ffb4b1", "#ffdbff", "#f2b2b6" , "#c0e2b9", "#e8e8e8"])'

#Sankey Diagram
library(networkD3)
sankey <- sankeyNetwork(Links = links, Nodes = nodes, Source = "source", Target = "target", Value = "value", NodeID = "name", LinkGroup = "group", NodeGroup = "group", colourScale = my_color, fontSize = 12, nodeWidth = 90, margin = 1, height = 650, width = 850)
print(sankey)

rm(list = ls())
gc()
