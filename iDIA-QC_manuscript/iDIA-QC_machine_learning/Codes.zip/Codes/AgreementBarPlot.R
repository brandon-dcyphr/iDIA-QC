#Agreement Bar Plot

#4 Raters
Dat4 <- read.csv("DIAQC_Label_17features_4raters_2groups_gaohh20221221-2050.csv", header = T)
Dat4 <- Dat4[,-4]

library(dplyr)
Dat4 <- arrange(Dat4, Feature_ID, Run_ID)

#F
FeatureList <- c("F1","F2","F3","F4","F5","F6","F7","F8","F9","F10","F11","F12","F13","F14","F15","LC","MS")

Dat4_F <- Dat4[which(Dat4$Feature_ID == "F1"),]
Stat_F <- vector()
for (i in 1:length(unique(Dat4_F$Run_ID))) {
  Stat_F[i] <- max(table(Dat4_F[which(Dat4_F$Run_ID == unique(Dat4_F$Run_ID)[i]), 3]))
}
rm(i)
Result <- as.data.frame(table(Stat_F) / length(unique(Dat4_F$Run_ID)))
rm(Dat4_F, Stat_F)

for (j in 2:17) {
  Dat4_F <- Dat4[which(Dat4$Feature_ID == FeatureList[j]),]
  Stat_F <- vector()
  for (i in 1:length(unique(Dat4_F$Run_ID))) {
    Stat_F[i] <- max(table(Dat4_F[which(Dat4_F$Run_ID == unique(Dat4_F$Run_ID)[i]), 3]))
  }
  rm(i)
  Result <- rbind(Result,as.data.frame(table(Stat_F) / length(unique(Dat4_F$Run_ID))))
  rm(Dat4_F, Stat_F)
}
rm(j)
rm(FeatureList)

Result$Stat_F
Result$Feature <- c(rep("F1",3), rep("F2",3), rep("F3",3), rep("F4",3), rep("F5",3), rep("F6",3), rep("F7",3), rep("F8",3), rep("F9",3), rep("F10",3), rep("F11",3), rep("F12",3), rep("F13",3), rep("F14",3), rep("F15",1), rep("LC",3), rep("MS",3))
colnames(Result)[1] <- "Agreement"
Result$Freq <- 100 * Result$Freq

library(ggplot2)
ggplot(Result, aes(x = Feature, weight = Freq, fill = Agreement)) +
  geom_bar(position = "stack") +
  theme_bw() +
  theme(panel.grid = element_blank()) +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 14, color = "black"), axis.text.y = element_text(size = 14, color = "black")) +
  labs(x = "Feature ID", y = "Percentage (%)") +
  scale_x_discrete(limits = c("F1","F2","F3","F4","F5","F6","F7","F8","F9","F10","F11","F12","F13","F14","F15","LC","MS")) +
  geom_text(aes(label = round(Freq, 0), y = Freq), position = position_stack(vjust = 0.5), size = 2.5) +
  scale_y_continuous(expand = c(0, 0), limits = c(-1, 101)) +
  ggtitle("4 Raters")

rm(Result, Dat4)

#5 Raters
Dat5 <- read.csv("DIAQC_Label_17features_5raters_2groups_gaohh20221221-2050.csv", header = T)
Dat5 <- Dat5[,-4]

library(dplyr)
Dat5 <- arrange(Dat5, Feature_ID, Run_ID)

#F
FeatureList <- c("F1","F2","F3","F4","F5","F6","F7","F8","F9","F10","F11","F12","F13","F14","F15","LC","MS")

Dat5_F <- Dat5[which(Dat5$Feature_ID == "F1"),]
Stat_F <- vector()
for (i in 1:length(unique(Dat5_F$Run_ID))) {
  Stat_F[i] <- max(table(Dat5_F[which(Dat5_F$Run_ID == unique(Dat5_F$Run_ID)[i]), 3]))
}
rm(i)
Result <- as.data.frame(table(Stat_F) / length(unique(Dat5_F$Run_ID)))
rm(Dat5_F, Stat_F)

for (j in 2:17) {
  Dat5_F <- Dat5[which(Dat5$Feature_ID == FeatureList[j]),]
  Stat_F <- vector()
  for (i in 1:length(unique(Dat5_F$Run_ID))) {
    Stat_F[i] <- max(table(Dat5_F[which(Dat5_F$Run_ID == unique(Dat5_F$Run_ID)[i]), 3]))
  }
  rm(i)
  Result <- rbind(Result,as.data.frame(table(Stat_F) / length(unique(Dat5_F$Run_ID))))
  rm(Dat5_F, Stat_F)
}
rm(j)
rm(FeatureList)

Result$Stat_F
Result$Feature <- c(rep("F1",3), rep("F2",3), rep("F3",3), rep("F4",3), rep("F5",3), rep("F6",3), rep("F7",3), rep("F8",3), rep("F9",3), rep("F10",3), rep("F11",3), rep("F12",3), rep("F13",3), rep("F14",3), rep("F15",1), rep("LC",3), rep("MS",3))
colnames(Result)[1] <- "Agreement"
Result$Freq <- 100 * Result$Freq

library(ggplot2)
ggplot(Result, aes(x = Feature, weight = Freq, fill = Agreement)) +
  geom_bar(position = "stack") +
  theme_bw() +
  theme(panel.grid = element_blank()) +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 14, color = "black"), axis.text.y = element_text(size = 14, color = "black")) +
  labs(x = "Feature ID", y = "Percentage (%)") +
  scale_x_discrete(limits = c("F1","F2","F3","F4","F5","F6","F7","F8","F9","F10","F11","F12","F13","F14","F15","LC","MS")) +
  geom_text(aes(label = round(Freq, 0), y = Freq), position = position_stack(vjust = 0.5), size = 2.5) +
  scale_y_continuous(expand = c(0, 0), limits = c(-1, 101)) +
  ggtitle("5 Raters")

rm(Result, Dat5)
