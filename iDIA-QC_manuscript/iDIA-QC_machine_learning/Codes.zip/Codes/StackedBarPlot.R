#Stacked Bar Plot

library(tidyverse)
Label <- as.data.frame(read_csv("DIAQC_2638_Label_17features_21raters_2groups_gaohh20221221-1640.csv"))
rownames(Label) <- NULL

A <- as.data.frame(rbind(
as.data.frame(table(Label$Label[which(Label$Feature_ID == "F1")])/length(which(Label$Feature_ID == "F1"))),
as.data.frame(table(Label$Label[which(Label$Feature_ID == "F2")])/length(which(Label$Feature_ID == "F2"))),
as.data.frame(table(Label$Label[which(Label$Feature_ID == "F3")])/length(which(Label$Feature_ID == "F3"))),
as.data.frame(table(Label$Label[which(Label$Feature_ID == "F4")])/length(which(Label$Feature_ID == "F4"))),
as.data.frame(table(Label$Label[which(Label$Feature_ID == "F5")])/length(which(Label$Feature_ID == "F5"))),
as.data.frame(table(Label$Label[which(Label$Feature_ID == "F6")])/length(which(Label$Feature_ID == "F6"))),
as.data.frame(table(Label$Label[which(Label$Feature_ID == "F7")])/length(which(Label$Feature_ID == "F7"))),
as.data.frame(table(Label$Label[which(Label$Feature_ID == "F8")])/length(which(Label$Feature_ID == "F8"))),
as.data.frame(table(Label$Label[which(Label$Feature_ID == "F9")])/length(which(Label$Feature_ID == "F9"))),
as.data.frame(table(Label$Label[which(Label$Feature_ID == "F10")])/length(which(Label$Feature_ID == "F10"))),
as.data.frame(table(Label$Label[which(Label$Feature_ID == "F11")])/length(which(Label$Feature_ID == "F11"))),
as.data.frame(table(Label$Label[which(Label$Feature_ID == "F12")])/length(which(Label$Feature_ID == "F12"))),
as.data.frame(table(Label$Label[which(Label$Feature_ID == "F13")])/length(which(Label$Feature_ID == "F13"))),
as.data.frame(table(Label$Label[which(Label$Feature_ID == "F14")])/length(which(Label$Feature_ID == "F14"))),
as.data.frame(table(Label$Label[which(Label$Feature_ID == "F15")])/length(which(Label$Feature_ID == "F15"))),
as.data.frame(table(Label$Label[which(Label$Feature_ID == "LC")])/length(which(Label$Feature_ID == "LC"))),
as.data.frame(table(Label$Label[which(Label$Feature_ID == "MS")])/length(which(Label$Feature_ID == "MS")))
))
A$Feature_ID <- rep(c("F1","F2","F3","F4","F5","F6","F7","F8","F9","F10","F11","F12","F13","F14","F15","LC","MS"), each = 2)
colnames(A) <- c("Label","Freq","Feature_ID")
A$Freq <- 100 * A$Freq

library(ggplot2)
ggplot(A, aes(x = Feature_ID, weight = Freq, fill = Label)) +
  geom_bar(position = "stack") +
  theme_bw() +
  theme(panel.grid = element_blank()) +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 14, color = "black"), axis.text.y = element_text(size = 14, color = "black")) +
  labs(x = "Feature ID", y = "Percentage (%)") +
  scale_x_discrete(limits = c("F1","F2","F3","F4","F5","F6","F7","F8","F9","F10","F11","F12","F13","F14","F15","LC","MS")) +
  geom_text(aes(label = round(Freq, 0), y = Freq), position = position_stack(vjust = 0.5), size = 3.5) +
  scale_y_continuous(expand = c(0, 0), limits = c(0, 101))

rm(A, Label)
gc()
