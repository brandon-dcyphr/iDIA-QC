#Datasets Analysis

#1 TPD A
library(tidyverse)
TPD_A <- read_tsv("1_QEHF1_TPD_A_output.tsv")
TPD_A <- TPD_A[,c("File.Name","Stripped.Sequence","Precursor.Id","RT.Start","RT.Stop","Precursor.Quantity","Protein.Ids","Precursor.Charge")]

length(unique(TPD_A$Stripped.Sequence))
A <- unique(TPD_A$Stripped.Sequence)
Index <- vector()
for (i in 1:length(A)) {
  a <- unique(as.vector(TPD_A[which(TPD_A$Stripped.Sequence == A[i]),]$Protein.Ids))
  if(length(a) > 1){
    Index <- c(Index, A[i])
  }
  print(i)
}
rm(i, a, A)
if(length(Index) > 0){
  write.csv(TPD_A[which(TPD_A$Stripped.Sequence %in% Index),], "1_Uniqueness_issue.csv", row.names = F)
  TPD_A <- TPD_A[-which(TPD_A$Stripped.Sequence %in% Index),]
}
rm(Index)

Index <- union(which(nchar(TPD_A$Stripped.Sequence) < 7), which(nchar(TPD_A$Stripped.Sequence) > 28))
write.csv(TPD_A[Index,], "1_peptide_length_issue.csv", row.names = F)
TPD_A <- TPD_A[-Index,]
rm(Index)

a <- nchar(TPD_A$Stripped.Sequence)
b <- gregexpr("K", TPD_A$Stripped.Sequence, fixed = T)
c <- gregexpr("R", TPD_A$Stripped.Sequence, fixed = T)
d <- gregexpr("KP", TPD_A$Stripped.Sequence, fixed = T)
e <- gregexpr("RP", TPD_A$Stripped.Sequence, fixed = T)
Index <- vector()
for (i in 1:nrow(TPD_A)) {
  Location <- unique(c(as.vector(b[[i]]), as.vector(c[[i]])))
  Location <- setdiff(Location, -1)
  Location <- setdiff(Location, unique(c(as.vector(d[[i]]), as.vector(e[[i]]), a[i])))
  if(length(Location) > 0){
    Index <- c(Index, i)
  }
}
rm(i)
write.csv(TPD_A[Index,], "1_cleavage_length_issue.csv", row.names = F)
TPD_A <- TPD_A[-Index,]
rm(a, b, c, d, e, Location, Index)

Index <- which(str_detect(TPD_A$Stripped.Sequence, "M") == "TRUE")
write.csv(TPD_A[Index,], "1_M_oxidation_issue.csv", row.names = F)
TPD_A <- TPD_A[-Index,]
rm(Index)

Index1 <- which(substring(TPD_A$Stripped.Sequence, 1, 1) == "Q")
Index2 <- union(which(str_detect(TPD_A$Stripped.Sequence, "NG") == "TRUE"), which(str_detect(TPD_A$Stripped.Sequence, "QG") == "TRUE"))
Index3 <- union(which(str_detect(TPD_A$Stripped.Sequence, "DQ") == "TRUE"), which(str_detect(TPD_A$Stripped.Sequence, "DP") == "TRUE"))
Index4 <- which(str_detect(TPD_A$Stripped.Sequence, "H") == "TRUE")
Index5 <- which(str_detect(TPD_A$Stripped.Sequence, "W") == "TRUE")
Index6 <- which(str_detect(TPD_A$Stripped.Sequence, "PP") == "TRUE")
Index7 <- which(str_detect(TPD_A$Stripped.Sequence, "SS") == "TRUE")
Index <- sort(unique(c(Index1, Index2, Index3, Index4, Index5, Index6, Index7)))
write.csv(TPD_A[Index,], "1_other_modification_issue.csv.csv", row.names = F)
TPD_A <- TPD_A[-Index,]
rm(Index)
rm(Index1, Index2, Index3, Index4, Index5, Index6, Index7)

write.csv(TPD_A, "1_dataset_peptides.csv", row.names = F)
rm(TPD_A)
gc()

#2 TPD B
library(tidyverse)
TPD_B <- read_tsv("2_QEHF1_TPD_B_output.tsv")
TPD_B <- TPD_B[,c("File.Name","Stripped.Sequence","Precursor.Id","RT.Start","RT.Stop","Precursor.Quantity","Protein.Ids","Precursor.Charge")]

length(unique(TPD_B$Stripped.Sequence))
A <- unique(TPD_B$Stripped.Sequence)
Index <- vector()
for (i in 1:length(A)) {
  a <- unique(as.vector(TPD_B[which(TPD_B$Stripped.Sequence == A[i]),]$Protein.Ids))
  if(length(a) > 1){
    Index <- c(Index, A[i])
  }
  print(i)
}
rm(i, a, A)
if(length(Index) > 0){
  write.csv(TPD_B[which(TPD_B$Stripped.Sequence %in% Index),], "2_Uniqueness_issue.csv", row.names = F)
  TPD_B <- TPD_B[-which(TPD_B$Stripped.Sequence %in% Index),]
}
rm(Index)

Index <- union(which(nchar(TPD_B$Stripped.Sequence) < 7), which(nchar(TPD_B$Stripped.Sequence) > 28))
write.csv(TPD_B[Index,], "2_peptide_length_issue.csv", row.names = F)
TPD_B <- TPD_B[-Index,]
rm(Index)

a <- nchar(TPD_B$Stripped.Sequence)
b <- gregexpr("K", TPD_B$Stripped.Sequence, fixed = T)
c <- gregexpr("R", TPD_B$Stripped.Sequence, fixed = T)
d <- gregexpr("KP", TPD_B$Stripped.Sequence, fixed = T)
e <- gregexpr("RP", TPD_B$Stripped.Sequence, fixed = T)
Index <- vector()
for (i in 1:nrow(TPD_B)) {
  Location <- unique(c(as.vector(b[[i]]), as.vector(c[[i]])))
  Location <- setdiff(Location, -1)
  Location <- setdiff(Location, unique(c(as.vector(d[[i]]), as.vector(e[[i]]), a[i])))
  if(length(Location) > 0){
    Index <- c(Index, i)
  }
}
rm(i)
write.csv(TPD_B[Index,], "2_cleavage_length_issue.csv", row.names = F)
TPD_B <- TPD_B[-Index,]
rm(a, b, c, d, e, Location, Index)

Index <- which(str_detect(TPD_B$Stripped.Sequence, "M") == "TRUE")
write.csv(TPD_B[Index,], "2_M_oxidation_issue.csv", row.names = F)
TPD_B <- TPD_B[-Index,]
rm(Index)

Index1 <- which(substring(TPD_B$Stripped.Sequence, 1, 1) == "Q")
Index2 <- union(which(str_detect(TPD_B$Stripped.Sequence, "NG") == "TRUE"), which(str_detect(TPD_B$Stripped.Sequence, "QG") == "TRUE"))
Index3 <- union(which(str_detect(TPD_B$Stripped.Sequence, "DQ") == "TRUE"), which(str_detect(TPD_B$Stripped.Sequence, "DP") == "TRUE"))
Index4 <- which(str_detect(TPD_B$Stripped.Sequence, "H") == "TRUE")
Index5 <- which(str_detect(TPD_B$Stripped.Sequence, "W") == "TRUE")
Index6 <- which(str_detect(TPD_B$Stripped.Sequence, "PP") == "TRUE")
Index7 <- which(str_detect(TPD_B$Stripped.Sequence, "SS") == "TRUE")
Index <- sort(unique(c(Index1, Index2, Index3, Index4, Index5, Index6, Index7)))
write.csv(TPD_B[Index,], "2_other_modification_issue.csv.csv", row.names = F)
TPD_B <- TPD_B[-Index,]
rm(Index)
rm(Index1, Index2, Index3, Index4, Index5, Index6, Index7)

write.csv(TPD_B, "2_dataset_peptides.csv", row.names = F)
rm(TPD_B)
gc()

#3 TPD C
library(tidyverse)
TPD_C <- read_tsv("3_TPD_C_output.tsv")
TPD_C <- TPD_C[,c("File.Name","Stripped.Sequence","Precursor.Id","RT.Start","RT.Stop","Precursor.Quantity","Protein.Ids","Precursor.Charge")]

length(unique(TPD_C$Stripped.Sequence))
A <- unique(TPD_C$Stripped.Sequence)
Index <- vector()
for (i in 1:length(A)) {
  a <- unique(as.vector(TPD_C[which(TPD_C$Stripped.Sequence == A[i]),]$Protein.Ids))
  if(length(a) > 1){
    Index <- c(Index, A[i])
  }
  print(i)
}
rm(i, a, A)
if(length(Index) > 0){
  write.csv(TPD_C[which(TPD_C$Stripped.Sequence %in% Index),], "3_Uniqueness_issue.csv", row.names = F)
  TPD_C <- TPD_C[-which(TPD_C$Stripped.Sequence %in% Index),]
}
rm(Index)

Index <- union(which(nchar(TPD_C$Stripped.Sequence) < 7), which(nchar(TPD_C$Stripped.Sequence) > 28))
write.csv(TPD_C[Index,], "3_peptide_length_issue.csv", row.names = F)
TPD_C <- TPD_C[-Index,]
rm(Index)

a <- nchar(TPD_C$Stripped.Sequence)
b <- gregexpr("K", TPD_C$Stripped.Sequence, fixed = T)
c <- gregexpr("R", TPD_C$Stripped.Sequence, fixed = T)
d <- gregexpr("KP", TPD_C$Stripped.Sequence, fixed = T)
e <- gregexpr("RP", TPD_C$Stripped.Sequence, fixed = T)
Index <- vector()
for (i in 1:nrow(TPD_C)) {
  Location <- unique(c(as.vector(b[[i]]), as.vector(c[[i]])))
  Location <- setdiff(Location, -1)
  Location <- setdiff(Location, unique(c(as.vector(d[[i]]), as.vector(e[[i]]), a[i])))
  if(length(Location) > 0){
    Index <- c(Index, i)
  }
}
rm(i)
write.csv(TPD_C[Index,], "3_cleavage_length_issue.csv", row.names = F)
TPD_C <- TPD_C[-Index,]
rm(a, b, c, d, e, Location, Index)

Index <- which(str_detect(TPD_C$Stripped.Sequence, "M") == "TRUE")
write.csv(TPD_C[Index,], "3_M_oxidation_issue.csv", row.names = F)
TPD_C <- TPD_C[-Index,]
rm(Index)

Index1 <- which(substring(TPD_C$Stripped.Sequence, 1, 1) == "Q")
Index2 <- union(which(str_detect(TPD_C$Stripped.Sequence, "NG") == "TRUE"), which(str_detect(TPD_C$Stripped.Sequence, "QG") == "TRUE"))
Index3 <- union(which(str_detect(TPD_C$Stripped.Sequence, "DQ") == "TRUE"), which(str_detect(TPD_C$Stripped.Sequence, "DP") == "TRUE"))
Index4 <- which(str_detect(TPD_C$Stripped.Sequence, "H") == "TRUE")
Index5 <- which(str_detect(TPD_C$Stripped.Sequence, "W") == "TRUE")
Index6 <- which(str_detect(TPD_C$Stripped.Sequence, "PP") == "TRUE")
Index7 <- which(str_detect(TPD_C$Stripped.Sequence, "SS") == "TRUE")
Index <- sort(unique(c(Index1, Index2, Index3, Index4, Index5, Index6, Index7)))
write.csv(TPD_C[Index,], "3_other_modification_issue.csv.csv", row.names = F)
TPD_C <- TPD_C[-Index,]
rm(Index)
rm(Index1, Index2, Index3, Index4, Index5, Index6, Index7)

write.csv(TPD_C, "3_dataset_peptides.csv", row.names = F)
rm(TPD_C)
gc()

#4 KRUK
library(tidyverse)
KRUK <- read_tsv("4_KRUK_output_20210401.tsv")
KRUK <- KRUK[,c("File.Name","Stripped.Sequence","Precursor.Id","RT.Start","RT.Stop","Precursor.Quantity","Protein.Ids","Precursor.Charge")]

length(unique(KRUK$Stripped.Sequence))
A <- unique(KRUK$Stripped.Sequence)
Index <- vector()
for (i in 1:length(A)) {
  a <- unique(as.vector(KRUK[which(KRUK$Stripped.Sequence == A[i]),]$Protein.Ids))
  if(length(a) > 1){
    Index <- c(Index, A[i])
  }
  print(i)
}
rm(i, a, A)
if(length(Index) > 0){
  write.csv(KRUK[which(KRUK$Stripped.Sequence %in% Index),], "4_Uniqueness_issue.csv", row.names = F)
  KRUK <- KRUK[-which(KRUK$Stripped.Sequence %in% Index),]
}
rm(Index)

Index <- union(which(nchar(KRUK$Stripped.Sequence) < 7), which(nchar(KRUK$Stripped.Sequence) > 28))
write.csv(KRUK[Index,], "4_peptide_length_issue.csv", row.names = F)
KRUK <- KRUK[-Index,]
rm(Index)

a <- nchar(KRUK$Stripped.Sequence)
b <- gregexpr("K", KRUK$Stripped.Sequence, fixed = T)
c <- gregexpr("R", KRUK$Stripped.Sequence, fixed = T)
d <- gregexpr("KP", KRUK$Stripped.Sequence, fixed = T)
e <- gregexpr("RP", KRUK$Stripped.Sequence, fixed = T)
Index <- vector()
for (i in 1:nrow(KRUK)) {
  Location <- unique(c(as.vector(b[[i]]), as.vector(c[[i]])))
  Location <- setdiff(Location, -1)
  Location <- setdiff(Location, unique(c(as.vector(d[[i]]), as.vector(e[[i]]), a[i])))
  if(length(Location) > 0){
    Index <- c(Index, i)
  }
}
rm(i)
write.csv(KRUK[Index,], "4_cleavage_length_issue.csv", row.names = F)
KRUK <- KRUK[-Index,]
rm(a, b, c, d, e, Location, Index)

Index <- which(str_detect(KRUK$Stripped.Sequence, "M") == "TRUE")
write.csv(KRUK[Index,], "4_M_oxidation_issue.csv", row.names = F)
KRUK <- KRUK[-Index,]
rm(Index)

Index1 <- which(substring(KRUK$Stripped.Sequence, 1, 1) == "Q")
Index2 <- union(which(str_detect(KRUK$Stripped.Sequence, "NG") == "TRUE"), which(str_detect(KRUK$Stripped.Sequence, "QG") == "TRUE"))
Index3 <- union(which(str_detect(KRUK$Stripped.Sequence, "DQ") == "TRUE"), which(str_detect(KRUK$Stripped.Sequence, "DP") == "TRUE"))
Index4 <- which(str_detect(KRUK$Stripped.Sequence, "H") == "TRUE")
Index5 <- which(str_detect(KRUK$Stripped.Sequence, "W") == "TRUE")
Index6 <- which(str_detect(KRUK$Stripped.Sequence, "PP") == "TRUE")
Index7 <- which(str_detect(KRUK$Stripped.Sequence, "SS") == "TRUE")
Index <- sort(unique(c(Index1, Index2, Index3, Index4, Index5, Index6, Index7)))
write.csv(KRUK[Index,], "4_other_modification_issue.csv.csv", row.names = F)
KRUK <- KRUK[-Index,]
rm(Index)
rm(Index1, Index2, Index3, Index4, Index5, Index6, Index7)

write.csv(KRUK, "4_dataset_peptides.csv", row.names = F)
rm(KRUK)
gc()

#5 PCXC
library(tidyverse)
PCXC <- read_tsv("5_PCXC.tsv")
PCXC <- PCXC[,c("File.Name","Stripped.Sequence","Precursor.Id","RT.Start","RT.Stop","Precursor.Quantity","Protein.Ids","Precursor.Charge")]

Index <- which(substring(PCXC$Protein.Ids, 1, 2) != "1/")
write.csv(PCXC[Index,], "5_Uniqueness_issue.csv", row.names = F)
PCXC <- PCXC[-Index,]
rm(Index)

Index <- union(which(nchar(PCXC$Stripped.Sequence) < 7), which(nchar(PCXC$Stripped.Sequence) > 28))
write.csv(PCXC[Index,], "5_peptide_length_issue.csv", row.names = F)
PCXC <- PCXC[-Index,]
rm(Index)

a <- nchar(PCXC$Stripped.Sequence)
b <- gregexpr("K", PCXC$Stripped.Sequence, fixed = T)
c <- gregexpr("R", PCXC$Stripped.Sequence, fixed = T)
d <- gregexpr("KP", PCXC$Stripped.Sequence, fixed = T)
e <- gregexpr("RP", PCXC$Stripped.Sequence, fixed = T)
Index <- vector()
for (i in 1:nrow(PCXC)) {
  Location <- unique(c(as.vector(b[[i]]), as.vector(c[[i]])))
  Location <- setdiff(Location, -1)
  Location <- setdiff(Location, unique(c(as.vector(d[[i]]), as.vector(e[[i]]), a[i])))
  if(length(Location) > 0){
    Index <- c(Index, i)
  }
}
rm(i)
write.csv(PCXC[Index,], "5_cleavage_length_issue.csv", row.names = F)
PCXC <- PCXC[-Index,]
rm(a, b, c, d, e, Location, Index)

Index <- which(str_detect(PCXC$Stripped.Sequence, "M") == "TRUE")
write.csv(PCXC[Index,], "5_M_oxidation_issue.csv", row.names = F)
PCXC <- PCXC[-Index,]
rm(Index)

Index1 <- which(substring(PCXC$Stripped.Sequence, 1, 1) == "Q")
Index2 <- union(which(str_detect(PCXC$Stripped.Sequence, "NG") == "TRUE"), which(str_detect(PCXC$Stripped.Sequence, "QG") == "TRUE"))
Index3 <- union(which(str_detect(PCXC$Stripped.Sequence, "DQ") == "TRUE"), which(str_detect(PCXC$Stripped.Sequence, "DP") == "TRUE"))
Index4 <- which(str_detect(PCXC$Stripped.Sequence, "H") == "TRUE")
Index5 <- which(str_detect(PCXC$Stripped.Sequence, "W") == "TRUE")
Index6 <- which(str_detect(PCXC$Stripped.Sequence, "PP") == "TRUE")
Index7 <- which(str_detect(PCXC$Stripped.Sequence, "SS") == "TRUE")
Index <- sort(unique(c(Index1, Index2, Index3, Index4, Index5, Index6, Index7)))
write.csv(PCXC[Index,], "5_other_modification_issue.csv.csv", row.names = F)
PCXC <- PCXC[-Index,]
rm(Index)
rm(Index1, Index2, Index3, Index4, Index5, Index6, Index7)

write.csv(PCXC, "5_dataset_peptides.csv", row.names = F)
rm(PCXC)
gc()

#6 OST
library(tidyverse)
OST <- read_tsv("6_OST_output.tsv")
OST <- OST[,c("File.Name","Stripped.Sequence","Precursor.Id","RT.Start","RT.Stop","Precursor.Quantity","Protein.Ids","Precursor.Charge")]

Index <- which(substring(OST$Protein.Ids, 1, 2) != "1/")
write.csv(OST[Index,], "6_Uniqueness_issue.csv", row.names = F)
OST <- OST[-Index,]
rm(Index)

Index <- union(which(nchar(OST$Stripped.Sequence) < 7), which(nchar(OST$Stripped.Sequence) > 28))
write.csv(OST[Index,], "6_peptide_length_issue.csv", row.names = F)
OST <- OST[-Index,]
rm(Index)

a <- nchar(OST$Stripped.Sequence)
b <- gregexpr("K", OST$Stripped.Sequence, fixed = T)
c <- gregexpr("R", OST$Stripped.Sequence, fixed = T)
d <- gregexpr("KP", OST$Stripped.Sequence, fixed = T)
e <- gregexpr("RP", OST$Stripped.Sequence, fixed = T)
Index <- vector()
for (i in 1:nrow(OST)) {
  Location <- unique(c(as.vector(b[[i]]), as.vector(c[[i]])))
  Location <- setdiff(Location, -1)
  Location <- setdiff(Location, unique(c(as.vector(d[[i]]), as.vector(e[[i]]), a[i])))
  if(length(Location) > 0){
    Index <- c(Index, i)
  }
}
rm(i)
write.csv(OST[Index,], "6_cleavage_length_issue.csv", row.names = F)
OST <- OST[-Index,]
rm(a, b, c, d, e, Location, Index)

Index <- which(str_detect(OST$Stripped.Sequence, "M") == "TRUE")
write.csv(OST[Index,], "6_M_oxidation_issue.csv", row.names = F)
OST <- OST[-Index,]
rm(Index)

Index1 <- which(substring(OST$Stripped.Sequence, 1, 1) == "Q")
Index2 <- union(which(str_detect(OST$Stripped.Sequence, "NG") == "TRUE"), which(str_detect(OST$Stripped.Sequence, "QG") == "TRUE"))
Index3 <- union(which(str_detect(OST$Stripped.Sequence, "DQ") == "TRUE"), which(str_detect(OST$Stripped.Sequence, "DP") == "TRUE"))
Index4 <- which(str_detect(OST$Stripped.Sequence, "H") == "TRUE")
Index5 <- which(str_detect(OST$Stripped.Sequence, "W") == "TRUE")
Index6 <- which(str_detect(OST$Stripped.Sequence, "PP") == "TRUE")
Index7 <- which(str_detect(OST$Stripped.Sequence, "SS") == "TRUE")
Index <- sort(unique(c(Index1, Index2, Index3, Index4, Index5, Index6, Index7)))
write.csv(OST[Index,], "6_other_modification_issue.csv.csv", row.names = F)
OST <- OST[-Index,]
rm(Index)
rm(Index1, Index2, Index3, Index4, Index5, Index6, Index7)

write.csv(OST, "6_dataset_peptides.csv", row.names = F)
rm(OST)
gc()

#7 PCSHA
library(tidyverse)
PCSHA <- read_tsv("7_PCSHA_output.tsv")
PCSHA <- PCSHA[,c("File.Name","Stripped.Sequence","Precursor.Id","RT.Start","RT.Stop","Precursor.Quantity","Protein.Ids","Precursor.Charge")]

length(unique(PCSHA$Stripped.Sequence))
A <- unique(PCSHA$Stripped.Sequence)
Index <- vector()
for (i in 1:length(A)) {
  a <- unique(as.vector(PCSHA[which(PCSHA$Stripped.Sequence == A[i]),]$Protein.Ids))
  if(length(a) > 1){
    Index <- c(Index, A[i])
  }
  print(i)
}
rm(i, a, A)
if(length(Index) > 0){
  write.csv(PCSHA[which(PCSHA$Stripped.Sequence %in% Index),], "7_Uniqueness_issue.csv", row.names = F)
  PCSHA <- PCSHA[-which(PCSHA$Stripped.Sequence %in% Index),]
}
rm(Index)

Index <- union(which(nchar(PCSHA$Stripped.Sequence) < 7), which(nchar(PCSHA$Stripped.Sequence) > 28))
write.csv(PCSHA[Index,], "7_peptide_length_issue.csv", row.names = F)
PCSHA <- PCSHA[-Index,]
rm(Index)

a <- nchar(PCSHA$Stripped.Sequence)
b <- gregexpr("K", PCSHA$Stripped.Sequence, fixed = T)
c <- gregexpr("R", PCSHA$Stripped.Sequence, fixed = T)
d <- gregexpr("KP", PCSHA$Stripped.Sequence, fixed = T)
e <- gregexpr("RP", PCSHA$Stripped.Sequence, fixed = T)
Index <- vector()
for (i in 1:nrow(PCSHA)) {
  Location <- unique(c(as.vector(b[[i]]), as.vector(c[[i]])))
  Location <- setdiff(Location, -1)
  Location <- setdiff(Location, unique(c(as.vector(d[[i]]), as.vector(e[[i]]), a[i])))
  if(length(Location) > 0){
    Index <- c(Index, i)
  }
}
rm(i)
write.csv(PCSHA[Index,], "7_cleavage_length_issue.csv", row.names = F)
PCSHA <- PCSHA[-Index,]
rm(a, b, c, d, e, Location, Index)

Index <- which(str_detect(PCSHA$Stripped.Sequence, "M") == "TRUE")
write.csv(PCSHA[Index,], "7_M_oxidation_issue.csv", row.names = F)
PCSHA <- PCSHA[-Index,]
rm(Index)

Index1 <- which(substring(PCSHA$Stripped.Sequence, 1, 1) == "Q")
Index2 <- union(which(str_detect(PCSHA$Stripped.Sequence, "NG") == "TRUE"), which(str_detect(PCSHA$Stripped.Sequence, "QG") == "TRUE"))
Index3 <- union(which(str_detect(PCSHA$Stripped.Sequence, "DQ") == "TRUE"), which(str_detect(PCSHA$Stripped.Sequence, "DP") == "TRUE"))
Index4 <- which(str_detect(PCSHA$Stripped.Sequence, "H") == "TRUE")
Index5 <- which(str_detect(PCSHA$Stripped.Sequence, "W") == "TRUE")
Index6 <- which(str_detect(PCSHA$Stripped.Sequence, "PP") == "TRUE")
Index7 <- which(str_detect(PCSHA$Stripped.Sequence, "SS") == "TRUE")
Index <- sort(unique(c(Index1, Index2, Index3, Index4, Index5, Index6, Index7)))
write.csv(PCSHA[Index,], "7_other_modification_issue.csv.csv", row.names = F)
PCSHA <- PCSHA[-Index,]
rm(Index)
rm(Index1, Index2, Index3, Index4, Index5, Index6, Index7)

write.csv(PCSHA, "7_dataset_peptides.csv", row.names = F)
rm(PCSHA)
gc()

#Intersection
library(tidyverse)
A1 <- read_csv("1_dataset_peptides.csv")
B2 <- read_csv("2_dataset_peptides.csv")
C3 <- read_csv("3_dataset_peptides.csv")
D4 <- read_csv("4_dataset_peptides.csv")
E5 <- read_csv("5_dataset_peptides.csv")
F6 <- read_csv("6_dataset_peptides.csv")
G7 <- read_csv("7_dataset_peptides.csv")

Intersection <- intersect(A1$Stripped.Sequence, B2$Stripped.Sequence)
Intersection <- intersect(Intersection, C3$Stripped.Sequence)
Intersection <- intersect(Intersection, D4$Stripped.Sequence)
Intersection <- intersect(Intersection, E5$Stripped.Sequence)
Intersection <- intersect(Intersection, F6$Stripped.Sequence)
Intersection <- intersect(Intersection, G7$Stripped.Sequence)

write.csv(Intersection, "Peptide_Intersection.csv", row.names = F)

rm(list = ls())
gc()
