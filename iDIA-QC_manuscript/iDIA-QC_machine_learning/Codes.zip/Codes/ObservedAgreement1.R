#Observed Agreement

#Data Loading
library(tidyverse)
Dat <- read_csv("DIAQC_2638_Label_17features_21raters_2groups_gaohh20221221-1640.csv")
Dat <- arrange(Dat, Instrument_ID, Run_ID, Feature_ID, Operator)
Dat$Run_ID <- paste(Dat$Run_ID, Dat$Feature_ID, sep = "_")
Dat <- Dat[,-3]

#Corrplot
par(mfrow = c(6,4))

#R01
Dat_R01 <- Dat[which(Dat$Instrument_ID == "R01"),]
R01 <- as.data.frame(matrix(Dat_R01$Label, length(unique(Dat_R01$Run_ID)), length(unique(Dat_R01$Operator)), byrow = T))
colnames(R01) <- unique(Dat_R01$Operator)
rownames(R01) <- unique(Dat_R01$Run_ID)

R01_Agreement <- matrix(0, ncol(R01), ncol(R01))
library(irr)
for (i in 1:ncol(R01)) {
  for (j in 1:ncol(R01)) {
    R01_Agreement[i,j] <- agree(R01[,c(i,j)])$value / 100
  }
}
rm(i,j)
rownames(R01_Agreement) <- colnames(R01)
colnames(R01_Agreement) <- colnames(R01)

library(corrplot)
corrplot.mixed(R01_Agreement, upper = "color", col.lim = c(0,1), tl.cex = 1.5, number.cex = 1.5)
R01_Agreement <- as.vector(R01_Agreement[upper.tri(R01_Agreement)])
rm(R01, Dat_R01)

#R02
Dat_R02 <- Dat[which(Dat$Instrument_ID == "R02"),]
R02 <- as.data.frame(matrix(Dat_R02$Label, length(unique(Dat_R02$Run_ID)), length(unique(Dat_R02$Operator)), byrow = T))
colnames(R02) <- unique(Dat_R02$Operator)
rownames(R02) <- unique(Dat_R02$Run_ID)

R02_Agreement <- matrix(0, ncol(R02), ncol(R02))
library(irr)
for (i in 1:ncol(R02)) {
  for (j in 1:ncol(R02)) {
    R02_Agreement[i,j] <- agree(R02[,c(i,j)])$value / 100
  }
}
rm(i,j)
rownames(R02_Agreement) <- colnames(R02)
colnames(R02_Agreement) <- colnames(R02)

library(corrplot)
corrplot.mixed(R02_Agreement, upper = "color", col.lim = c(0,1), tl.cex = 1.5, number.cex = 1.5)
R02_Agreement <- as.vector(R02_Agreement[upper.tri(R02_Agreement)])
rm(R02, Dat_R02)

#W03
Dat_W03 <- Dat[which(Dat$Instrument_ID == "W03"),]
W03 <- as.data.frame(matrix(Dat_W03$Label, length(unique(Dat_W03$Run_ID)), length(unique(Dat_W03$Operator)), byrow = T))
colnames(W03) <- unique(Dat_W03$Operator)
rownames(W03) <- unique(Dat_W03$Run_ID)

W03_Agreement <- matrix(0, ncol(W03), ncol(W03))
library(irr)
for (i in 1:ncol(W03)) {
  for (j in 1:ncol(W03)) {
    W03_Agreement[i,j] <- agree(W03[,c(i,j)])$value / 100
  }
}
rm(i,j)
rownames(W03_Agreement) <- colnames(W03)
colnames(W03_Agreement) <- colnames(W03)

library(corrplot)
corrplot.mixed(W03_Agreement, upper = "color", col.lim = c(0,1), tl.cex = 1.5, number.cex = 1.5)
W03_Agreement <- as.vector(W03_Agreement[upper.tri(W03_Agreement)])
rm(W03, Dat_W03)

#R04
Dat_R04 <- Dat[which(Dat$Instrument_ID == "R04"),]
R04 <- as.data.frame(matrix(Dat_R04$Label, length(unique(Dat_R04$Run_ID)), length(unique(Dat_R04$Operator)), byrow = T))
colnames(R04) <- unique(Dat_R04$Operator)
rownames(R04) <- unique(Dat_R04$Run_ID)

R04_Agreement <- matrix(0, ncol(R04), ncol(R04))
library(irr)
for (i in 1:ncol(R04)) {
  for (j in 1:ncol(R04)) {
    R04_Agreement[i,j] <- agree(R04[,c(i,j)])$value / 100
  }
}
rm(i,j)
rownames(R04_Agreement) <- colnames(R04)
colnames(R04_Agreement) <- colnames(R04)

library(corrplot)
corrplot.mixed(R04_Agreement, upper = "color", col.lim = c(0,1), tl.cex = 1.5, number.cex = 1.5)
R04_Agreement <- as.vector(R04_Agreement[upper.tri(R04_Agreement)])
rm(R04, Dat_R04)

#R05
Dat_R05 <- Dat[which(Dat$Instrument_ID == "R05"),]
R05 <- as.data.frame(matrix(Dat_R05$Label, length(unique(Dat_R05$Run_ID)), length(unique(Dat_R05$Operator)), byrow = T))
colnames(R05) <- unique(Dat_R05$Operator)
rownames(R05) <- unique(Dat_R05$Run_ID)

R05_Agreement <- matrix(0, ncol(R05), ncol(R05))
library(irr)
for (i in 1:ncol(R05)) {
  for (j in 1:ncol(R05)) {
    R05_Agreement[i,j] <- agree(R05[,c(i,j)])$value / 100
  }
}
rm(i,j)
rownames(R05_Agreement) <- colnames(R05)
colnames(R05_Agreement) <- colnames(R05)

library(corrplot)
corrplot.mixed(R05_Agreement, upper = "color", col.lim = c(0,1), tl.cex = 1.5, number.cex = 1.5)
R05_Agreement <- as.vector(R05_Agreement[upper.tri(R05_Agreement)])
rm(R05, Dat_R05)

#W06
Dat_W06 <- Dat[which(Dat$Instrument_ID == "W06"),]
W06 <- as.data.frame(matrix(Dat_W06$Label, length(unique(Dat_W06$Run_ID)), length(unique(Dat_W06$Operator)), byrow = T))
colnames(W06) <- unique(Dat_W06$Operator)
rownames(W06) <- unique(Dat_W06$Run_ID)

W06_Agreement <- matrix(0, ncol(W06), ncol(W06))
library(irr)
for (i in 1:ncol(W06)) {
  for (j in 1:ncol(W06)) {
    W06_Agreement[i,j] <- agree(W06[,c(i,j)])$value / 100
  }
}
rm(i,j)
rownames(W06_Agreement) <- colnames(W06)
colnames(W06_Agreement) <- colnames(W06)

library(corrplot)
corrplot.mixed(W06_Agreement, upper = "color", col.lim = c(0,1), tl.cex = 1.5, number.cex = 1.5)
W06_Agreement <- as.vector(W06_Agreement[upper.tri(W06_Agreement)])
rm(W06, Dat_W06)

#W07
Dat_W07 <- Dat[which(Dat$Instrument_ID == "W07"),]
W07 <- as.data.frame(matrix(Dat_W07$Label, length(unique(Dat_W07$Run_ID)), length(unique(Dat_W07$Operator)), byrow = T))
colnames(W07) <- unique(Dat_W07$Operator)
rownames(W07) <- unique(Dat_W07$Run_ID)

W07_Agreement <- matrix(0, ncol(W07), ncol(W07))
library(irr)
for (i in 1:ncol(W07)) {
  for (j in 1:ncol(W07)) {
    W07_Agreement[i,j] <- agree(W07[,c(i,j)])$value / 100
  }
}
rm(i,j)
rownames(W07_Agreement) <- colnames(W07)
colnames(W07_Agreement) <- colnames(W07)

library(corrplot)
corrplot.mixed(W07_Agreement, upper = "color", col.lim = c(0,1), tl.cex = 1.5, number.cex = 1.5)
W07_Agreement <- as.vector(W07_Agreement[upper.tri(W07_Agreement)])
rm(W07, Dat_W07)

#R08
Dat_R08 <- Dat[which(Dat$Instrument_ID == "R08"),]
R08 <- as.data.frame(matrix(Dat_R08$Label, length(unique(Dat_R08$Run_ID)), length(unique(Dat_R08$Operator)), byrow = T))
colnames(R08) <- unique(Dat_R08$Operator)
rownames(R08) <- unique(Dat_R08$Run_ID)

R08_Agreement <- matrix(0, ncol(R08), ncol(R08))
library(irr)
for (i in 1:ncol(R08)) {
  for (j in 1:ncol(R08)) {
    R08_Agreement[i,j] <- agree(R08[,c(i,j)])$value / 100
  }
}
rm(i,j)
rownames(R08_Agreement) <- colnames(R08)
colnames(R08_Agreement) <- colnames(R08)

library(corrplot)
corrplot.mixed(R08_Agreement, upper = "color", col.lim = c(0,1), tl.cex = 1.5, number.cex = 1.5)
R08_Agreement <- as.vector(R08_Agreement[upper.tri(R08_Agreement)])
rm(R08, Dat_R08)

#R09
Dat_R09 <- Dat[which(Dat$Instrument_ID == "R09"),]
R09 <- as.data.frame(matrix(Dat_R09$Label, length(unique(Dat_R09$Run_ID)), length(unique(Dat_R09$Operator)), byrow = T))
colnames(R09) <- unique(Dat_R09$Operator)
rownames(R09) <- unique(Dat_R09$Run_ID)

R09_Agreement <- matrix(0, ncol(R09), ncol(R09))
library(irr)
for (i in 1:ncol(R09)) {
  for (j in 1:ncol(R09)) {
    R09_Agreement[i,j] <- agree(R09[,c(i,j)])$value / 100
  }
}
rm(i,j)
rownames(R09_Agreement) <- colnames(R09)
colnames(R09_Agreement) <- colnames(R09)

library(corrplot)
corrplot.mixed(R09_Agreement, upper = "color", col.lim = c(0,1), tl.cex = 1.5, number.cex = 1.5)
R09_Agreement <- as.vector(R09_Agreement[upper.tri(R09_Agreement)])
rm(R09, Dat_R09)

#D10
Dat_D10 <- Dat[which(Dat$Instrument_ID == "D10"),]
D10 <- as.data.frame(matrix(Dat_D10$Label, length(unique(Dat_D10$Run_ID)), length(unique(Dat_D10$Operator)), byrow = T))
colnames(D10) <- unique(Dat_D10$Operator)
rownames(D10) <- unique(Dat_D10$Run_ID)

D10_Agreement <- matrix(0, ncol(D10), ncol(D10))
library(irr)
for (i in 1:ncol(D10)) {
  for (j in 1:ncol(D10)) {
    D10_Agreement[i,j] <- agree(D10[,c(i,j)])$value / 100
  }
}
rm(i,j)
rownames(D10_Agreement) <- colnames(D10)
colnames(D10_Agreement) <- colnames(D10)

library(corrplot)
corrplot.mixed(D10_Agreement, upper = "color", col.lim = c(0,1), tl.cex = 1.5, number.cex = 1.5)
D10_Agreement <- as.vector(D10_Agreement[upper.tri(D10_Agreement)])
rm(D10, Dat_D10)

#R11
Dat_R11 <- Dat[which(Dat$Instrument_ID == "R11"),]
R11 <- as.data.frame(matrix(Dat_R11$Label, length(unique(Dat_R11$Run_ID)), length(unique(Dat_R11$Operator)), byrow = T))
colnames(R11) <- unique(Dat_R11$Operator)
rownames(R11) <- unique(Dat_R11$Run_ID)

R11_Agreement <- matrix(0, ncol(R11), ncol(R11))
library(irr)
for (i in 1:ncol(R11)) {
  for (j in 1:ncol(R11)) {
    R11_Agreement[i,j] <- agree(R11[,c(i,j)])$value / 100
  }
}
rm(i,j)
rownames(R11_Agreement) <- colnames(R11)
colnames(R11_Agreement) <- colnames(R11)

library(corrplot)
corrplot.mixed(R11_Agreement, upper = "color", col.lim = c(0,1), tl.cex = 1.5, number.cex = 1.5)
R11_Agreement <- as.vector(R11_Agreement[upper.tri(R11_Agreement)])
rm(R11, Dat_R11)

#R12
Dat_R12 <- Dat[which(Dat$Instrument_ID == "R12"),]
R12 <- as.data.frame(matrix(Dat_R12$Label, length(unique(Dat_R12$Run_ID)), length(unique(Dat_R12$Operator)), byrow = T))
colnames(R12) <- unique(Dat_R12$Operator)
rownames(R12) <- unique(Dat_R12$Run_ID)

R12_Agreement <- matrix(0, ncol(R12), ncol(R12))
library(irr)
for (i in 1:ncol(R12)) {
  for (j in 1:ncol(R12)) {
    R12_Agreement[i,j] <- agree(R12[,c(i,j)])$value / 100
  }
}
rm(i,j)
rownames(R12_Agreement) <- colnames(R12)
colnames(R12_Agreement) <- colnames(R12)

library(corrplot)
corrplot.mixed(R12_Agreement, upper = "color", col.lim = c(0,1), tl.cex = 1.5, number.cex = 1.5)
R12_Agreement <- as.vector(R12_Agreement[upper.tri(R12_Agreement)])
rm(R12, Dat_R12)

#D13
Dat_D13 <- Dat[which(Dat$Instrument_ID == "D13"),]
D13 <- as.data.frame(matrix(Dat_D13$Label, length(unique(Dat_D13$Run_ID)), length(unique(Dat_D13$Operator)), byrow = T))
colnames(D13) <- unique(Dat_D13$Operator)
rownames(D13) <- unique(Dat_D13$Run_ID)

D13_Agreement <- matrix(0, ncol(D13), ncol(D13))
library(irr)
for (i in 1:ncol(D13)) {
  for (j in 1:ncol(D13)) {
    D13_Agreement[i,j] <- agree(D13[,c(i,j)])$value / 100
  }
}
rm(i,j)
rownames(D13_Agreement) <- colnames(D13)
colnames(D13_Agreement) <- colnames(D13)

library(corrplot)
corrplot.mixed(D13_Agreement, upper = "color", col.lim = c(0,1), tl.cex = 1.5, number.cex = 1.5)
D13_Agreement <- as.vector(D13_Agreement[upper.tri(D13_Agreement)])
rm(D13, Dat_D13)

#W14
Dat_W14 <- Dat[which(Dat$Instrument_ID == "W14"),]
W14 <- as.data.frame(matrix(Dat_W14$Label, length(unique(Dat_W14$Run_ID)), length(unique(Dat_W14$Operator)), byrow = T))
colnames(W14) <- unique(Dat_W14$Operator)
rownames(W14) <- unique(Dat_W14$Run_ID)

W14_Agreement <- matrix(0, ncol(W14), ncol(W14))
library(irr)
for (i in 1:ncol(W14)) {
  for (j in 1:ncol(W14)) {
    W14_Agreement[i,j] <- agree(W14[,c(i,j)])$value / 100
  }
}
rm(i,j)
rownames(W14_Agreement) <- colnames(W14)
colnames(W14_Agreement) <- colnames(W14)

library(corrplot)
corrplot.mixed(W14_Agreement, upper = "color", col.lim = c(0,1), tl.cex = 1.5, number.cex = 1.5)
W14_Agreement <- as.vector(W14_Agreement[upper.tri(W14_Agreement)])
rm(W14, Dat_W14)

#R15
Dat_R15 <- Dat[which(Dat$Instrument_ID == "R15"),]
R15 <- as.data.frame(matrix(Dat_R15$Label, length(unique(Dat_R15$Run_ID)), length(unique(Dat_R15$Operator)), byrow = T))
colnames(R15) <- unique(Dat_R15$Operator)
rownames(R15) <- unique(Dat_R15$Run_ID)

R15_Agreement <- matrix(0, ncol(R15), ncol(R15))
library(irr)
for (i in 1:ncol(R15)) {
  for (j in 1:ncol(R15)) {
    R15_Agreement[i,j] <- agree(R15[,c(i,j)])$value / 100
  }
}
rm(i,j)
rownames(R15_Agreement) <- colnames(R15)
colnames(R15_Agreement) <- colnames(R15)

library(corrplot)
corrplot.mixed(R15_Agreement, upper = "color", col.lim = c(0,1), tl.cex = 1.5, number.cex = 1.5)
R15_Agreement <- as.vector(R15_Agreement[upper.tri(R15_Agreement)])
rm(R15, Dat_R15)

#D16
Dat_D16 <- Dat[which(Dat$Instrument_ID == "D16"),]
D16 <- as.data.frame(matrix(Dat_D16$Label, length(unique(Dat_D16$Run_ID)), length(unique(Dat_D16$Operator)), byrow = T))
colnames(D16) <- unique(Dat_D16$Operator)
rownames(D16) <- unique(Dat_D16$Run_ID)

D16_Agreement <- matrix(0, ncol(D16), ncol(D16))
library(irr)
for (i in 1:ncol(D16)) {
  for (j in 1:ncol(D16)) {
    D16_Agreement[i,j] <- agree(D16[,c(i,j)])$value / 100
  }
}
rm(i,j)
rownames(D16_Agreement) <- colnames(D16)
colnames(D16_Agreement) <- colnames(D16)

library(corrplot)
corrplot.mixed(D16_Agreement, upper = "color", col.lim = c(0,1), tl.cex = 1.5, number.cex = 1.5)
D16_Agreement <- as.vector(D16_Agreement[upper.tri(D16_Agreement)])
rm(D16, Dat_D16)

#D17
Dat_D17 <- Dat[which(Dat$Instrument_ID == "D17"),]
D17 <- as.data.frame(matrix(Dat_D17$Label, length(unique(Dat_D17$Run_ID)), length(unique(Dat_D17$Operator)), byrow = T))
colnames(D17) <- unique(Dat_D17$Operator)
rownames(D17) <- unique(Dat_D17$Run_ID)

D17_Agreement <- matrix(0, ncol(D17), ncol(D17))
library(irr)
for (i in 1:ncol(D17)) {
  for (j in 1:ncol(D17)) {
    D17_Agreement[i,j] <- agree(D17[,c(i,j)])$value / 100
  }
}
rm(i,j)
rownames(D17_Agreement) <- colnames(D17)
colnames(D17_Agreement) <- colnames(D17)

library(corrplot)
corrplot.mixed(D17_Agreement, upper = "color", col.lim = c(0,1), tl.cex = 1.5, number.cex = 1.5)
D17_Agreement <- as.vector(D17_Agreement[upper.tri(D17_Agreement)])
rm(D17, Dat_D17)

#R18
Dat_R18 <- Dat[which(Dat$Instrument_ID == "R18"),]
R18 <- as.data.frame(matrix(Dat_R18$Label, length(unique(Dat_R18$Run_ID)), length(unique(Dat_R18$Operator)), byrow = T))
colnames(R18) <- unique(Dat_R18$Operator)
rownames(R18) <- unique(Dat_R18$Run_ID)

R18_Agreement <- matrix(0, ncol(R18), ncol(R18))
library(irr)
for (i in 1:ncol(R18)) {
  for (j in 1:ncol(R18)) {
    R18_Agreement[i,j] <- agree(R18[,c(i,j)])$value / 100
  }
}
rm(i,j)
rownames(R18_Agreement) <- colnames(R18)
colnames(R18_Agreement) <- colnames(R18)

library(corrplot)
corrplot.mixed(R18_Agreement, upper = "color", col.lim = c(0,1), tl.cex = 1.5, number.cex = 1.5)
R18_Agreement <- as.vector(R18_Agreement[upper.tri(R18_Agreement)])
rm(R18, Dat_R18)

#R19
Dat_R19 <- Dat[which(Dat$Instrument_ID == "R19"),]
R19 <- as.data.frame(matrix(Dat_R19$Label, length(unique(Dat_R19$Run_ID)), length(unique(Dat_R19$Operator)), byrow = T))
colnames(R19) <- unique(Dat_R19$Operator)
rownames(R19) <- unique(Dat_R19$Run_ID)

R19_Agreement <- matrix(0, ncol(R19), ncol(R19))
library(irr)
for (i in 1:ncol(R19)) {
  for (j in 1:ncol(R19)) {
    R19_Agreement[i,j] <- agree(R19[,c(i,j)])$value / 100
  }
}
rm(i,j)
rownames(R19_Agreement) <- colnames(R19)
colnames(R19_Agreement) <- colnames(R19)

library(corrplot)
corrplot.mixed(R19_Agreement, upper = "color", col.lim = c(0,1), tl.cex = 1.5, number.cex = 1.5)
R19_Agreement <- as.vector(R19_Agreement[upper.tri(R19_Agreement)])
rm(R19, Dat_R19)

#R20
Dat_R20 <- Dat[which(Dat$Instrument_ID == "R20"),]
R20 <- as.data.frame(matrix(Dat_R20$Label, length(unique(Dat_R20$Run_ID)), length(unique(Dat_R20$Operator)), byrow = T))
colnames(R20) <- unique(Dat_R20$Operator)
rownames(R20) <- unique(Dat_R20$Run_ID)

R20_Agreement <- matrix(0, ncol(R20), ncol(R20))
library(irr)
for (i in 1:ncol(R20)) {
  for (j in 1:ncol(R20)) {
    R20_Agreement[i,j] <- agree(R20[,c(i,j)])$value / 100
  }
}
rm(i,j)
rownames(R20_Agreement) <- colnames(R20)
colnames(R20_Agreement) <- colnames(R20)

library(corrplot)
corrplot.mixed(R20_Agreement, upper = "color", col.lim = c(0,1), tl.cex = 1.5, number.cex = 1.5)
R20_Agreement <- as.vector(R20_Agreement[upper.tri(R20_Agreement)])
rm(R20, Dat_R20)

#R21
Dat_R21 <- Dat[which(Dat$Instrument_ID == "R21"),]
R21 <- as.data.frame(matrix(Dat_R21$Label, length(unique(Dat_R21$Run_ID)), length(unique(Dat_R21$Operator)), byrow = T))
colnames(R21) <- unique(Dat_R21$Operator)
rownames(R21) <- unique(Dat_R21$Run_ID)

R21_Agreement <- matrix(0, ncol(R21), ncol(R21))
library(irr)
for (i in 1:ncol(R21)) {
  for (j in 1:ncol(R21)) {
    R21_Agreement[i,j] <- agree(R21[,c(i,j)])$value / 100
  }
}
rm(i,j)
rownames(R21_Agreement) <- colnames(R21)
colnames(R21_Agreement) <- colnames(R21)

library(corrplot)
corrplot.mixed(R21_Agreement, upper = "color", col.lim = c(0,1), tl.cex = 1.5, number.cex = 1.5)
R21_Agreement <- as.vector(R21_Agreement[upper.tri(R21_Agreement)])
rm(R21, Dat_R21)

#Boxplot
par(mfrow = c(1,1))
Dat_Agreement <- data.frame(Agreement = c(R01_Agreement, R02_Agreement, W03_Agreement, R04_Agreement, R05_Agreement, W06_Agreement, W07_Agreement, R08_Agreement, R09_Agreement, D10_Agreement, R11_Agreement, R12_Agreement, D13_Agreement, W14_Agreement, R15_Agreement, D16_Agreement, D17_Agreement, R18_Agreement, R19_Agreement, R20_Agreement, R21_Agreement),
                            Instrument = c(rep("R01",10), rep("R02",10), rep("W03",6), rep("R04",6), rep("R05",10), rep("W06",6), rep("W07",10), rep("R08",10), rep("R09",6), rep("D10",10), rep("R11",10), rep("R12",10), rep("D13",6), rep("W14",10), rep("R15",10), rep("D16",6), rep("D17",10), rep("R18",6), rep("R19",6), rep("R20",6), rep("R21",6)))
library(ggplot2)
ggplot(Dat_Agreement, aes(x = Instrument, y = Agreement)) +
  geom_boxplot(fill = "#E18727FF") +
  geom_jitter(size = 1) +
  theme_bw() +
  theme(panel.grid = element_blank()) +
  theme(axis.title.x = element_text(size = 15), axis.title.y = element_text(size = 15)) +
  theme(axis.text.x = element_text(size = 14, color = "black"), axis.text.y = element_text(size = 14, color = "black")) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  labs(x = "Instrument ID", y = "Score") +
  scale_x_discrete(limits = c("R01","R02","W03","R04","R05","W06","W07","R08","R09","D10","R11","R12","D13","W14","R15","D16","D17","R18","R19","R20","R21")) +
  scale_y_continuous(expand = c(0, 0), limits = c(0.5, 1))

rm(list = ls())
gc()
