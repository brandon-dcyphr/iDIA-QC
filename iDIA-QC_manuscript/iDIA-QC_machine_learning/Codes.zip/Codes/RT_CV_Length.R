#Codes

#Package
library(tidyverse)

#Peptides
Peptides <- read.csv("iDIAQC_peptide_candidate_in_model20240425-2300.csv", header = T)

#Files
Files <- read_csv("Selected_Run_files_20220129.csv")

#Matrix
List <- list()
List2 <- list()
for (i in 1:nrow(Files)) {
  L <- as.data.frame(read_tsv(paste0(Files$Run_name[i], "_mainoutput.tsv")))
  L <- L[,c("Stripped.Sequence","Precursor.Quantity","RT")]
  L <- L[which(L$Stripped.Sequence %in% Peptides$Peptide_sequence),]
  L <- arrange(L, desc(Precursor.Quantity))
  L <- L[match(Peptides$Peptide_sequence, L$Stripped.Sequence),]
  List[[i]] <- L$Precursor.Quantity
  List2[[i]] <- L$RT
}
rm(i, L)
A <- matrix(unlist(List), nrow = 33, ncol = 36, byrow = F)
rownames(A) <- Peptides$Peptide_sequence
colnames(A) <- Files$Run_name
A <- log2(A)
B <- matrix(unlist(List2), nrow = 33, ncol = 36, byrow = F)
rownames(B) <- Peptides$Peptide_sequence
colnames(B) <- Files$Run_name
rm(List, List2, Files)

#RT
f <- function(x)
{
  return(median(x, na.rm = T))
}
RT <- apply(B, 1, f)
write.csv(data.frame(Peptide = Peptides$Peptide_sequence, RT_Median = as.numeric(RT)), "RT_Median.csv", row.names = F)
rm(f, B)
rm(RT)

#CV
CV <- vector()
for (i in 1:33) {
  CV[i] <- sd(A[i,], na.rm = T)/mean(A[i,], na.rm = T)
}
write.csv(data.frame(Peptide = Peptides$Peptide_sequence, CV = CV), "CV.csv", row.names = F)
rm(i, A)

#Length
Length <- nchar(Peptides$Peptide_sequence)
write.csv(data.frame(Peptide = Peptides$Peptide_sequence, Length = Length), "Length.csv", row.names = F)
rm(Length)

#Variance
library(ComplexHeatmap)
M <- matrix(as.character(ifelse(CV >= 0.2, ">=20%", "<20%")), ncol = 1)
rownames(M) <- Peptides$Peptide_sequence
rm(CV, Peptides)
Heatmap(M, show_column_names = F, row_split = rownames(M),
        col = structure(c("#20854EFF", "#BC3C29FF"), names = c("<20%", ">=20%")))
rm(M)
gc()
