#RaterHeatmap

#OverviewRaterHeatmap
library(readr)
Dat <- as.data.frame(read_csv("Data_labeling_rater_distribution_20221213.csv"))

Dat2 <- Dat[,c(3,5:9)]
rownames(Dat2) <- Dat2$Instrument_ID
Dat2 <- Dat2[,-1]

library(ComplexHeatmap)
set.seed(3)
ha <- HeatmapAnnotation(Type = Dat$`Instrument type...1`, Type1 = Dat$`Instrument type...2`, RawNumber = Dat$Raw_number)
Heatmap(t(Dat2), column_split = rownames(Dat2), top_annotation = ha, row_split = colnames(Dat2), show_column_names = F,
        cell_fun = function(j, i, x, y, w, h, col) {
          grid.text(t(Dat2)[i, j], x, y)
        },
        col = structure(c("#E64B35FF","#00A087FF","#3C5488FF","#8491B4FF","#7E6148FF","#B09C85FF","#3B4992FF","#008B45FF","#631879FF","#008280FF","#BB0021FF","#5F559BFF","#A20056FF","#808180FF","#1B1919FF","#BC3C29FF","#0072B5FF","#E18727FF"), names = c("A", "B", "C", "D","E","F","G","H","I","J","K","L","M","X","Y","AA","AB","KX")))
rm(Dat, Dat2, ha)
gc()
